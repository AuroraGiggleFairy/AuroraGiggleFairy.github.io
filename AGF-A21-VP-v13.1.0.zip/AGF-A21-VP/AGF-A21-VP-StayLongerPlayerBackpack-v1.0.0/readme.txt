VanillaPlus - StayLongerPlayerBackpack
A21 - Version 1.0.0


______________________________________________________________________________________________________________
***This is a standalone mod, works well with vanilla plus.***


______________________________________________________________________________________________________________
MAIN Features:
-Player's backpacks stick around for 5 hours instead of 1.


______________________________________________________________________________________________________________
If you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
	-All questions welcome from newcomers to seasoned 7d2d people.
	
	
______________________________________________________________________________________________________________
More Details about the author and other sites described on the README in the CORE modlet.