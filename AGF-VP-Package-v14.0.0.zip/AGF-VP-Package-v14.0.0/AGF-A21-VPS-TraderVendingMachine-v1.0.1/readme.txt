VanillaPlus - TraderVendingMachine
A21 - Version 1.0.1



***Works Standalone, and works well with Vanilla Plus***


______________________________________________________________________________________________________________________
README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Installation and Removal Notes
4. Features
5. Change Log


_____________________________________________________________________________________________________________________
1.  ABOUT AUTHOR
	-My name is AuroraGiggleFairy (AGF), previously known as RilesPlus
	-Started playing 7d2d during Alpha 12
	-Started attempting to mod in Alpha 17
	-First published a mod during Alpha 18
	-Where to find:
		https://discord.gg/Vm5eyW6N4r
		https://auroragigglefairy.github.io/
		https://www.twitch.tv/AuroraGiggleFairy
		https://7daystodiemods.com/
		https://www.nexusmods.com/7daystodie

		
______________________________________________________________________________________________________________________
2.  MOD PHILOSOPHY
	-Preferably easy installation and use!
	-Goal: Enhance Vanilla Gameplay!
	-Feedback and Testing is Beneficial!
	-Detailed Notes for Individual Preference and Mod Learning!
	-Full Language Support (best I can.)
		
	"The best mods rely on community involvement."


______________________________________________________________________________________________________________________
3.  INSTALLATION and REMOVAL NOTES
	*First, if you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
		-All questions welcome from newcombers to seasoned 7d2d people.

	-This is a server-side mod, meaning this mod can be installed on JUST the server and will work automatically for joining players.
	-Works with EAC on or off.
	-All 14 languages supported
	
	-TraderVendingMachine is SAFE to install on new game or existing game.
	-TraderVendingMachine is SAFE to remove from an existing game.


______________________________________________________________________________________________________________________
4.  FEATURES

	-High trader stage unlocks option to purchase a trader managed vending machines.
	-Trader managed vending machines are the ones that come with food and drinks that reset daily.


______________________________________________________________________________________________________________________
5.  CHANGELOG

v1.0.1
-Changed the tier stage of the vending machines to match rare tools (100).
-Added the "energy" and "water" vending machine.
-Lowered the "trader stage" requirement to access the vending machines.
-Updated the ReadMe file to new format.


	
