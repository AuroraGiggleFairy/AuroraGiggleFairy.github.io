VanillaPlus - VehicleStorage
A21 - Version 1.0.0


______________________________________________________________________________________________________________
***Requires VP-1Core, otherwise known as Vanilla Plus Core***


______________________________________________________________________________________________________________
MAIN Features:
-Adds 1 row of storage to each vehicle.


______________________________________________________________________________________________________________
If you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
	-All questions welcome from newcombers to seasoned 7d2d people.
	
	
______________________________________________________________________________________________________________
More Details about the author and other sites described on the README in the CORE modlet.