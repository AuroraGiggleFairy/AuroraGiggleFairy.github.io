Backpack84
V2.0 - Version 2.3.1


______________________________________________________________________________________________________________________
README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Installation and Removal Notes
4. Features
5. Change Log


_____________________________________________________________________________________________________________________
1.  ABOUT AUTHOR
	-My name is AuroraGiggleFairy (AGF), previously known as RilesPlus
	-Started playing 7d2d during Alpha 12
	-Started attempting to mod in Alpha 17
	-First published a mod during Alpha 18
	-Where to find:
		https://discord.gg/Vm5eyW6N4r
		https://auroragigglefairy.github.io/
		https://www.twitch.tv/AuroraGiggleFairy
		https://7daystodiemods.com/
		https://www.nexusmods.com/7daystodie

		
______________________________________________________________________________________________________________________
2.  MOD PHILOSOPHY
	-Preferably easy installation and use!
	-Goal: Enhance Vanilla Gameplay!
	-Feedback and Testing is Beneficial!
	-Detailed Notes for Individual Preference and Mod Learning!
	-Full Language Support (best I can.)
		
	"The best mods rely on community involvement."


______________________________________________________________________________________________________________________
3.  INSTALLATION and REMOVAL NOTES
	*First, if you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
		-All questions welcome from newcombers to seasoned 7d2d people.

	-This is a server-side mod, meaning this mod can be installed on JUST the server and will work automatically for joining players.
	-Works with EAC on or off.
	-All 14 languages supported
	-BACKPACK84 is SAFE to install on new or existing games.
	-BACKPACK84 is DANGEROUS to remove from an existing game.
		-NOTE: you can swap from Backpack72 to Backpack84 safely on an existing game.


______________________________________________________________________________________________________________________
4.  FEATURES

	-84 Slot Backpack, with 3 rows of encumbrance  slots (36 slots)
	-Updated encumbrance slots, buffs, twith interaction and perks. 
	-PackMule does free up all 36 slots.
	-Mobility is in sync with vanilla.
	-Lockable slots that is EASY to tell what is locked and what isn't.
	-Adds a craftable larger storage of wood/iron/steel, slots of 120/144/168.
	-Large storages are variant blocks with multiple shapes to choose from.


______________________________________________________________________________________________________________________
5.  CHANGELOG
v2.3.1
-Updated PackMule Localization

v2.3.0
-Updated to V2.
-Updated the path to access block shapes with V2 version.

v2.2.2
-Added missing localization edit for pack mule level 5 description.

v2.2.1
-Corrected a controller gamepad Icon display

v2.2.0
-Updated for V1.0 (b325)
-Vanilla, New Lockable Slots system, I just changed entirely how it appears for ease of use

v2.1.1
-Added the half cube
-fixed rotation options for new shapes

v2.1.0
-Added multiple common shapes that are paintable to the large chests options
-Turned the wood/iron/steel into variant blocks with those new shapes.

v2.0.0
-Updated for V1.0
-Removed previous version of storage blocks
-Created the new player storage system with one that goes up to 168 slots
-Mobility effect from capacity follows vanilla
-Localization updated
-Added effects on capacity from twitch interaction

v1.3.0
-Added variety of shape options to the LARGE storage containers.

v1.2.9
-Updated for A21.2(b30)

v1.2.8
-Broken down writeable storage chests are still writeable now.

v1.2.7
-skipped 1.2.6 to make it even with the other sized one.
-Corrected a width change of the text letting you know you are comparing items. Now it fits correctly.
-Correct text of descriptions that were going beyond the background.

v1.2.5
-Due to change in A21.1, updated the column size of "unlocked-by"
-Buff info panel on the character view screen now matches width of backpack



	
