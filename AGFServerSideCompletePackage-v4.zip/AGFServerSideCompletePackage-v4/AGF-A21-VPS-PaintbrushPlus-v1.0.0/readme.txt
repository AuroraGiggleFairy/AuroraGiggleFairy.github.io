VanillaPlus - Paintbrush Plus
A21 - Version 1.0.0


______________________________________________________________________________________________________________
***Works standalone and is part of Vanilla Plus***


______________________________________________________________________________________________________________
MAIN Features:
-Painting costs ZERO paint.
-You can hold down the trigger to continue painting.
-Painting distance is reduced to prevent accidental long distance painting.


______________________________________________________________________________________________________________
If you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
	-All questions welcome from newcomers to seasoned 7d2d people.
	
	
______________________________________________________________________________________________________________
More Details about the author and other sites described on the README in the CORE modlet.