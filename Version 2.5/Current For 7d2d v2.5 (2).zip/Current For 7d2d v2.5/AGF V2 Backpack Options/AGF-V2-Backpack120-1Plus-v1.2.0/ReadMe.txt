Backpack120-1
7d2d Version 2 - v1.2.0


______________________________________________________________________________________________________________________
README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Installation and Removal Notes
4. Features
5. Change Log


_____________________________________________________________________________________________________________________
1.  ABOUT AUTHOR
	-My name is AuroraGiggleFairy (AGF), previously known as RilesPlus
	-Started playing 7d2d during Alpha 12
	-Started attempting to mod in Alpha 17
	-First published a mod during Alpha 18
	-Where to find:
		https://discord.gg/Vm5eyW6N4r
		https://auroragigglefairy.github.io/
		https://www.twitch.tv/AuroraGiggleFairy
		https://7daystodiemods.com/
		https://www.nexusmods.com/7daystodie

		
______________________________________________________________________________________________________________________
2.  MOD PHILOSOPHY
	-Preferably easy installation and use!
	-Goal: Enhance Vanilla Gameplay!
	-Feedback and Testing is Beneficial!
	-Detailed Notes for Individual Preference and Mod Learning!
	-Full Language Support (best I can.)
		
	"The best mods rely on community involvement."


______________________________________________________________________________________________________________________
3.  INSTALLATION and REMOVAL NOTES
	*First, if you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
		-All questions welcome from newcombers to seasoned 7d2d people.

	-This is a server-side mod, meaning this mod can be installed on JUST the server and will work automatically for joining players.
	-Works with EAC on or off.
	-All 13 languages supported
	-Backpack120-1 is SAFE to install on new or existing games.
	-Backpack120-1 is DANGEROUS to remove from an existing game.
		-NOTE: you can swap from Backpack72 to Backpack84 and Backpack120-1 safely on an existing game.


______________________________________________________________________________________________________________________
4.  FEATURES

	-119 Slot Backpack, with 3 rows of encumbrance  slots (68 slots)
	-Updated encumbrance slots, buffs, twith interaction and perks. 
	-PackMule does free up all 68 slots.
	-Mobility is in sync with vanilla.
	-Lockable slots that is EASY to tell what is locked and what isn't.
	-Adds a craftable larger storage of wood/iron/steel, slots of 120/144/168.
	-Large storages are variant blocks with multiple shapes to choose from.
	-Breaking a larger storage returns it to your inventory.
	
	*Some overlap of UI may occur as this is a LARGE backpack. You can modify UI zoom in game menu if you wish.*


______________________________________________________________________________________________________________________
5.  CHANGELOG
v1.2.0
-Updated to work with version 2.5.

v1.1.0
-When you break an insecure large storage, the block itself (not items inside) return to your inventory.
-Added several more block shape options.
-Updated Localization

v1.0.0
-Made the mod