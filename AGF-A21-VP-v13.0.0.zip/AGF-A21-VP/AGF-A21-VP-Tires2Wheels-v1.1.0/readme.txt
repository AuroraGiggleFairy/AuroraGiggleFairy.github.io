VanillaPlus - Tires2Wheels
A21 - Version 1.1.0


______________________________________________________________________________________________________________
***Requires VP-1Core, otherwise known as Vanilla Plus Core***


______________________________________________________________________________________________________________
MAIN Features:
-To make wheels, you can either use Acid or good used tires you have found.
-20% chance of getting a full wheel or tire from destroying them found in the world.
-You can also scrap the tires for plastic.


______________________________________________________________________________________________________________
If you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
	-All questions welcome from newcombers to seasoned 7d2d people.
	
	
______________________________________________________________________________________________________________
More Details about the author and other sites described on the README in the CORE modlet.