VanillaPlus - ProgressiveBiomeSpawning
A21 - Version 1.1.0


______________________________________________________________________________________________________________
***This is a standalone mod, works well with vanilla plus.***


______________________________________________________________________________________________________________
MAIN Features:
-Progressive Biome Spawning Increase,
	-Forest is a bit easier now due to increase timid animals.
	-Desert to Snow to Wasteland, wasteland at night is now a nightmare.
-The point? Gives a server something for newcomers and pros alike.


______________________________________________________________________________________________________________
If you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
	-All questions welcome from newcomers to seasoned 7d2d people.
	
	
______________________________________________________________________________________________________________
More Details about the author and other sites described on the README in the CORE modlet.


