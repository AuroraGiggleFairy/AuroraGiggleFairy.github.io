Backpack60
7d2d Version 2 - v2.4.0


______________________________________________________________________________________________________________________
README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Installation and Removal Notes
4. Features
5. Change Log


_____________________________________________________________________________________________________________________
1.  ABOUT AUTHOR
	-My name is AuroraGiggleFairy (AGF), previously known as RilesPlus
	-Started playing 7d2d during Alpha 12
	-Started attempting to mod in Alpha 17
	-First published a mod during Alpha 18
	-Where to find:
		https://discord.gg/Vm5eyW6N4r
		https://auroragigglefairy.github.io/
		https://www.twitch.tv/AuroraGiggleFairy
		https://7daystodiemods.com/
		https://www.nexusmods.com/7daystodie

		
______________________________________________________________________________________________________________________
2.  MOD PHILOSOPHY
	-Preferably easy installation and use!
	-Goal: Enhance Vanilla Gameplay!
	-Feedback and Testing is Beneficial!
	-Detailed Notes for Individual Preference and Mod Learning!
	-Full Language Support (best I can.)
		
	"The best mods rely on community involvement."


______________________________________________________________________________________________________________________
3.  INSTALLATION and REMOVAL NOTES
	*First, if you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
		-All questions welcome from newcombers to seasoned 7d2d people.

	-This is a server-side mod, meaning this mod can be installed on JUST the server and will work automatically for joining players.
	-Works with EAC on or off.
	-All 14 languages supported
	-Backpack60 is SAFE to install on new or existing games.
	-Backpack60 is DANGEROUS to remove from an existing game.
		-NOTE: you can swap from Backpack60 to Backpack72 OR Backpack84 safely on an existing game.


______________________________________________________________________________________________________________________
4.  FEATURES

	-Visual size of inventory is the same as vanilla - as in no shrinking required.
	-60 Slot Backpack, with 3 rows of encumbrance  slots (30 slots).
	-Updated encumbrance slots, buffs, twith interaction and perks. 
	-PackMule does free up all 30 slots.
	-Mobility is in sync with vanilla.
	-Lockable slots that is EASY to tell what is locked and what isn't.
	-Adds a craftable larger storage of wood/iron/steel, slots of 60/80/100.
	-Large storages are variant blocks with multiple shapes to choose from.


______________________________________________________________________________________________________________________
5.  CHANGELOG
v2.4.0
-Updated for 7d2d version 2.2
-Lockable slots share same style across backpack, storages, and vehicles.

v2.3.2
-updated packmule localization again for value changes.

v2.3.1
-Updated PackMule Localization

v2.3.0
-Updated to V2.
-Updated the path to access block shapes with V2 version.
-Skipped all the other versions to match current.

v1.0.1
-Fixed inventory border height.

v1.0.0
-created the mod based on my v1 mods for backpack84 slots.