VanillaPlus - PumpkinsPlus
7d2d V2 - v2.0.3


______________________________________________________________________________________________________________________
README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Installation and Removal Notes
4. Features
5. Change Log


_____________________________________________________________________________________________________________________
1.  ABOUT AUTHOR
	-My name is AuroraGiggleFairy (AGF), previously known as RilesPlus
	-Started playing 7d2d during Alpha 12
	-Started attempting to mod in Alpha 17
	-First published a mod during Alpha 18
	-Where to find:
		https://discord.gg/Vm5eyW6N4r
		https://auroragigglefairy.github.io/
		https://www.twitch.tv/AuroraGiggleFairy
		https://7daystodiemods.com/
		https://www.nexusmods.com/7daystodie

		
______________________________________________________________________________________________________________________
2.  MOD PHILOSOPHY
	-Preferably easy installation and use!
	-Goal: Enhance Vanilla Gameplay!
	-Feedback and Testing is Beneficial!
	-Detailed Notes for Individual Preference and Mod Learning!
	-Full Language Support (best I can.)
		
	"The best mods rely on community involvement."


______________________________________________________________________________________________________________________
3.  INSTALLATION and REMOVAL NOTES
	*First, if you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
		-All questions welcome from newcombers to seasoned 7d2d people.

	-This is a server-side mod, meaning this mod can be installed on JUST the server and will work automatically for joining players.
	-Works with EAC on or off.
	-All 14 languages supported
	-BattleAxeMod is SAFE to install on new or existing games.
	-BattleAxeMod is DANGEROUS to remove from an existing game.


______________________________________________________________________________________________________________________
4.  FEATURES

	-Throw pumpkins that explode like molotovs.
	-Wear a pumpkin as a cosmetic mod on your helmet!
	-You can also bundle the pumpkin head mod.
	-The helmet mod scraps the same way a jack-o-lantern does... into plant fibers.


	This mod idea came from a collection of friends/twitch viewers/discord peeps, and other insane people like AGF.
	(Lots of mechanics ideas came from IceRogue)
	(Molo-Jack-Ovs' name came from ProfSeatbelt)


______________________________________________________________________________________________________________________
5.  CHANGELOG
v2.0.3
-updated for 7d2d Version 2

v2.0.2
-updated localization and colors to fit with other VP theme

v2.0.1
-Drop mesh of the pumpkin helmet is now a jack-o-lantern. LOL

v2.0.0
-Updated to work with V1
-Change the hold type of molo-jack-ovs (not in your hand directly, but shows throwing animation)

v1.2.0
-Added bundle version of mod
-Updated ReadMe to my new format.


