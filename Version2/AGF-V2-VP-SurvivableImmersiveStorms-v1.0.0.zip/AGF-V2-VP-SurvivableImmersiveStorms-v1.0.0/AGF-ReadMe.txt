VanillaPlus - SurvivableImmersiveStorms
7d2d Version 2 - v1.0.0


______________________________________________________________________________________________________________________
README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Installation and Removal Notes
4. Features
5. Change Log


_____________________________________________________________________________________________________________________
1.  ABOUT AUTHOR
	-My name is AuroraGiggleFairy (AGF), previously known as RilesPlus
	-Started playing 7d2d during Alpha 8
	-Started attempting to mod in Alpha 17
	-First published a mod during Alpha 18
	-Where to find:
		https://discord.gg/Vm5eyW6N4r
		https://auroragigglefairy.github.io/
		https://www.twitch.tv/AuroraGiggleFairy
		https://7daystodiemods.com/
		https://www.nexusmods.com/7daystodie

		
______________________________________________________________________________________________________________________
2.  MOD PHILOSOPHY
	-Preferably easy installation and use!
	-Goal: Enhance Vanilla Gameplay!
	-Feedback and Testing is Beneficial!
	-Detailed Notes for Individual Preference and Mod Learning!
	-Full Language Support (best I can.)
		
	"The best mods rely on community involvement."


______________________________________________________________________________________________________________________
3.  INSTALLATION and REMOVAL NOTES
	*First, if you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
		-All questions welcome from newcombers to seasoned 7d2d people.

	-This is a server-side mod, meaning this mod can be installed on JUST the server and will work automatically for joining players.
	-Works with EAC on or off.
	-All 14 languages supported
	-SurvivableImmersiveStorms is SAFE to install on new or existing games.
	-SurvivableImmersiveStorms is SAFE to remove from an existing game.


______________________________________________________________________________________________________________________
4.  FEATURES

	-The Siren alert for storms is gone
	-Visually more noticeable when storm is incoming
	-Visibility feels impacted
	-Mobility is slightly affected
	-Safe from negative effects for first 10 seconds
	    -30 seconds if you have the "badge"
	-Negative effects can give you a 20 second +10% xp gain
	-Smoothies: Every minute, give 10 second grace period from negative effects
	
	Storm Effects:
	-Forest: Lightning Strikes (shocked)
	-Burnt: High Fire Risk (catch on fire)
	-Desert: Flying Sand and Dry Heat (abrassions and water deductions)
	-Snow: Slipping on Ice (Knockdowns with Concussions)
	-Wasteland: Radiation Illness (Fatigue, Puking, and small Bleeds)	

______________________________________________________________________________________________________________________
5.  CHANGELOG
v1.0.0
-Just made it!