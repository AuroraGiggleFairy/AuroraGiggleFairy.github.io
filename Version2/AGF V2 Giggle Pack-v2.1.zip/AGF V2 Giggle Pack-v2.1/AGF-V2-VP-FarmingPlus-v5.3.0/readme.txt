VanillaPlus - FarmingPlus
7d2d Version 2 - v5.3.1


______________________________________________________________________________________________________________________
README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Installation and Removal Notes
4. Features
5. Change Log


_____________________________________________________________________________________________________________________
1.  ABOUT AUTHOR
	-My name is AuroraGiggleFairy (AGF), previously known as RilesPlus
	-Started playing 7d2d during Alpha 12
	-Started attempting to mod in Alpha 17
	-First published a mod during Alpha 18
	-Where to find:
		https://discord.gg/Vm5eyW6N4r
		https://auroragigglefairy.github.io/
		https://www.twitch.tv/AuroraGiggleFairy
		https://7daystodiemods.com/
		https://www.nexusmods.com/7daystodie

		
______________________________________________________________________________________________________________________
2.  MOD PHILOSOPHY
	-Preferably easy installation and use!
	-Goal: Enhance Vanilla Gameplay!
	-Feedback and Testing is Beneficial!
	-Detailed Notes for Individual Preference and Mod Learning!
	-Full Language Support (best I can.)
		
	"The best mods rely on community involvement."


______________________________________________________________________________________________________________________
3.  INSTALLATION and REMOVAL NOTES
	*First, if you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
		-All questions welcome from newcombers to seasoned 7d2d people.

	-This is a server-side mod, meaning this mod can be installed on JUST the server and will work automatically for joining players.
	-Works with EAC on or off.
	-All 13 languages supported
	-FarmingPlus is SAFE to install on new or existing games.
	-FarmingPlus is DANGEROUS to remove from an existing game.


______________________________________________________________________________________________________________________
4.  FEATURES

	-Birdnest and Beehives now plantable for eggs, feathers, and honey.
		-Naturally discovered through traders and loot.
		-Unlocks at seed crafting level 20.
	-A new "Seed Station" that offers faster seed crafting and organization.
	-x5 Farming, level 20 Seed Crafting:
		-Take 5 seeds, click recipe, and craft them into a single x5 seed.
		-Essentially 1 seed acts like 5 in one space.
		-Seeds, except for mushrooms and birdnests, requires x5 farm plots as well.
	-Level 3 of Living Off the Land craft x70 faster at seed workbench.
	-x25 Variants are available as well.


______________________________________________________________________________________________________________________
5.  CHANGELOG
v5.3.1
-Max Damage of seed station is now 500 (increased).
-Breaking the seed station returns it to your inventory.
-Icon fixed to show which recipes have to be done at the seed station.

v5.3.0
-Now can craft x5 and x25 variants directly from inventory.

v5.2.0
-Will now only apply purple book edits if you have my purple book installed.

v5.1.1
-Changed how the seeds alphabetically sort themselves.

v5.1.0
-changed beeflower ingredients to require crops, not the seeds. Also changed the amount.
-Reduced crafting time of beeflower and birdnest to match other crops.
-Added Seed Workbench (aka hydroponic farm block), required to craft x5 farming.
-Station has categories for regular seeds/farm plots and another for x5 variants.
-Added x25 varients along with multiple recipes to obtain them.
-Made categories at seed station for single, x5, and x25 variants.
-Updated sorting orders for both in menus and alphabetical ordering in inventories/storages.


v5.0.1
-Fixed an error that allowed crazy farming of Hops.

v5.0.0
-Updated for 7d2d Version 2.
-Removed my previous seed collecting system.
-Updated purple book adjustments.
-Reduced probability of finding nest or beeflower in world and traders.
-reduced how much eggs, feathers, and honey you get per "crop" for better gameplay.
-Updated the code to better access vanilla code to account for possible game updates.

v4.0.0
-Updated to fit zooming features on HUD.

v3.1.0
-Updated the windows section to work with HUD update.
-Updated added seeds and x5 seeds to appropriately work with Farmer Armor.
-You now only find 1 honey with bee's, unless you get the extra from farmer armor.
-Changed crafting time of birdnest and beehive from 20 to 3 seconds.
-Changed birdnest's cornmeal ingredient count from 5 to 25.
-World crops have an additional seed drop chance with the farmer armor seed bonus, at half the chance.

v3.0.0
-Updated to V1

v2.0.0
-Updated the Bee Flower progression blocks to use a better model since A20! came out.
-REVAMPED the seed drop chance on player planted crops.
-Removed the recipe of 3 seeds per flower at max Living Off the Land.
-Returned the x5 versions of crops and farmplots from my A19 mods.

v1.2.0
-World crops 10% seed drop.
-Increased seed drop chance.

v1.1.0
-Tier 3 of living off the land actually reduces seed requirements for planting.
-Updated ReadMe to new format.

	
