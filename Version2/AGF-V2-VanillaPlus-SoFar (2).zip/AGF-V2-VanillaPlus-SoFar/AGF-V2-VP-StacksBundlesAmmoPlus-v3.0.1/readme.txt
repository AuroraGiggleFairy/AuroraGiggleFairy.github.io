7d2d V1.0+
VanillaPlus - StacksBundlesAmmoPlus
Version 3.0.1

______________________________________________________________________________________________________________________
README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Installation and Removal Notes
4. Features
5. Change Log


_____________________________________________________________________________________________________________________
1.  ABOUT AUTHOR
	-My name is AuroraGiggleFairy (AGF), previously known as RilesPlus
	-Started playing 7d2d during Alpha 12
	-Started attempting to mod in Alpha 17
	-First published a mod during Alpha 18
	-Where to find:
		https://discord.gg/Vm5eyW6N4r
		https://auroragigglefairy.github.io/
		https://www.twitch.tv/AuroraGiggleFairy
		https://7daystodiemods.com/
		https://www.nexusmods.com/7daystodie

		
______________________________________________________________________________________________________________________
2.  MOD PHILOSOPHY
	-Preferably easy installation and use!
	-Goal: Enhance Vanilla Gameplay!
	-Feedback and Testing is Beneficial!
	-Detailed Notes for Individual Preference and Mod Learning!
	-Full Language Support (best I can.)
		
	"The best mods rely on community involvement."


______________________________________________________________________________________________________________________
3.  INSTALLATION and REMOVAL NOTES
	*First, if you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
		-All questions welcome from newcombers to seasoned 7d2d people.

	-This is a server-side mod, meaning this mod can be installed on JUST the server and will work automatically for joining players.
	-Works with EAC on or off.
	-All 13 languages supported
	
	-StacksBundlesAmmoPlus is SAFE to install on new game or existing game.
	-StacksBundlesAmmoPlus is DANGEROUS to remove from an existing game.


______________________________________________________________________________________________________________________
4.  FEATURES

	-Simplified stack sizes that keeps close to vanilla experience.
	-Simplified Stack Sizes:
		-Bundles and consumables stack to 50
		-Ammo stacks to 500
		-Resources are generally 500, 1000, or 6000
		-Gas, Coins, and plant fibers stack to 30000
		-Placeable blocks (like workstations) to 500
		-Farming and General blocks to 5000
		-Existing Bundles modified to new stack sizes
		
	-Rebundle Bundles after opening.
	-Bundles icon now tinted for a visual differentation assistance.
		
	-Scrap Ammo into bundles that contain the ammo's ingredients. Open to collect.
		-Have a lot of scrapped ammo? Combine 100 or 1000 to open more at once
	
	-All archery ammo requires Feathers (instead of either feathers OR plastic)
	-Feathers can be crafted from plastic
	
	
______________________________________________________________________________________________________________________
5.  CHANGELOG
v3.0.1
-Added the missing correction to gas can bundle localization

v3.0.0
-Updated name to StacksBundlesAmmoPlus
-Merged my rebundling of bundles mod into this one

v2.0.1
-Made boiled water stack to 500 as its purpose has changed.

v2.0.0
-Updated to V1.0
-Fixed the cloth ingredient count for flaming arrows/bolts
-Merged my "AmmoPlus" into this mod

v1.1.1
-Land claim blocks to be stackable
-Sham Sandwhiches to have higehr stack

v1.1.0
-Medical Bags now stack to 500 instead of 50
-resourceHeadlight now stacks to 500 instead of 50 and economic value reduced
-oldCash now stacks to 30k instead of default 10,000
-resourceFeather now stacks to 30k and economic value reduced
-resourceOil now stacks to 500 instead of 50

v1.0.2
-Updated all gas recipes for A21.1
-Updated the ReadMe file to new format.


	
