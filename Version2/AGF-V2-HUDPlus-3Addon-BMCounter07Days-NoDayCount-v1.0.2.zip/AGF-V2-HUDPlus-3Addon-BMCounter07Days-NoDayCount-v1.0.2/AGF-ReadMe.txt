HUDPlus - BMCounter07Days-NoDayCount
7d2d V2 - v1.0.2


*** This only works if Bloodmoon is set to Every 7 Days without variations! ***

*** This version replaces the Day Count***

______________________________________________________________________________________________________________________
README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Installation and Removal Notes
4. Features
5. Change Log


_____________________________________________________________________________________________________________________
1.  ABOUT AUTHOR
	-My name is AuroraGiggleFairy (AGF), previously known as RilesPlus
	-Started playing 7d2d during Alpha 12
	-Started attempting to mod in Alpha 17
	-First published a mod during Alpha 18
	-Where to find:
		https://discord.gg/Vm5eyW6N4r
		https://auroragigglefairy.github.io/
		https://www.twitch.tv/AuroraGiggleFairy
		https://7daystodiemods.com/
		https://www.nexusmods.com/7daystodie

		
______________________________________________________________________________________________________________________
2.  MOD PHILOSOPHY
	-Preferably easy installation and use!
	-Goal: Enhance Vanilla Gameplay!
	-Feedback and Testing is Beneficial!
	-Detailed Notes for Individual Preference and Mod Learning!
	-Full Language Support (best I can.)
		
	"The best mods rely on community involvement."


______________________________________________________________________________________________________________________
3.  INSTALLATION and REMOVAL NOTES
	*First, if you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
		-All questions welcome from newcombers to seasoned 7d2d people.

	***Requires the Main HUDPlus mod, as this is an optional addon to it.***

	-This is a server-side mod, meaning this mod can be installed on JUST the server and will work automatically for joining players.
	-Works with EAC on or off.
	-All 14 languages supported
	-HUDPlus - BMCounter07Days-NoDayCount is SAFE to install on new or existing games.
	-HUDPLus - BMCounter07Days-NoDayCount is SAFE to remove from an existing game.


______________________________________________________________________________________________________________________
4.  FEATURES

	-This replaces the day count with the Next Blood Moon Day Countdown
		-This is when bloodmoon is set for every 7 days, no variations.

______________________________________________________________________________________________________________________
5.  CHANGELOG
v1.0.2
-Corrected German Translation of "Next Bloodmoon" from Weiter Blutmond to Nächster Blutmond

v1.0.1
-Made the background of the day/time section with rounded corners to match

v1.0.0
-Just made it.