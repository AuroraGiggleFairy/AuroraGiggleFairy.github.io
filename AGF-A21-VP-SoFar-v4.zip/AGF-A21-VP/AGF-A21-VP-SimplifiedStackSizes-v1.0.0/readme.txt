VanillaPlus - SimplifiedStackSizes
A21 - Version 1.0.0


______________________________________________________________________________________________________________
***Requires Vanilla Plus Core***


______________________________________________________________________________________________________________
MAIN Features:
-Simplified stack sizes that keeps close to vanilla experience.
-Bundles and consumables stack to 50
-Ammo stacks to 500
-Resources are generally 500, 1000, or 6000
-Gas, Coins, and plant fibers stack to 30000
-Placeable blocks (like workstations) to 500
-Farming and General blocks to 5000
-Opening bundles adapted to new stack sizes


______________________________________________________________________________________________________________
If you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
	-All questions welcome from newcomers to seasoned 7d2d people.
	
	
______________________________________________________________________________________________________________
More Details about the author and other sites described on the README in the CORE modlet.