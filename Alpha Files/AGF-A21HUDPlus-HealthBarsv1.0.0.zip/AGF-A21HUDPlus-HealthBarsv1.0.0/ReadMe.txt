HUDPlus - HealthBars
A21 - Version 1.0.0

______________________________________________________________________________________________________________
***REQUIRES HUDPlus to work, as this is an ADDON.***

Works server side.

______________________________________________________________________________________________________________
MAIN Features:
	-Adds enemy health bars with an AGF style.

	
______________________________________________________________________________________________________________
If you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
	-All questions welcome from newcombers to seasoned 7d2d people.
	
	