HUDPlus Addon
A20 - Version 1.4.0
Description and Updates




*****First, if you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r

*****You must turn EAC off for this to work other stats to appear... *****

*****All players must have this patch installed in order to work on your server... ****




Here are the additional stats included:
	-Food and Water now show amount instead of percentage
	-Lootstage and xp to next level is shown
	-With the chat output, zombie killes, player deaths, and pvp kills are shown



