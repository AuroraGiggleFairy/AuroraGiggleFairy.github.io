HUDPlus
A20 - Version 1.5.1
Description and Updates


______________________________________________________________________________________________________________________
README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Features


_____________________________________________________________________________________________________________________
1.  ABOUT AUTHOR
	-Name changed from RilesPlus to AuroraGiggleFairy (AGF)
	-Started playing 7d2d during Alpha 12
	-Started attempting to mod in Alpha 17
	-First published a mod during Alpha 18
	-Where to find:
		https://discord.gg/Vm5eyW6N4r
		https://auroragigglefairy.github.io/
		https://www.twitch.tv/AuroraGiggleFairy
		https://7daystodiemods.com/
		https://www.nexusmods.com/7daystodie
		
		
______________________________________________________________________________________________________________________
2.  MOD PHILOSOPHY
	-Singeplayer AND/OR Server-Side!
	-Goal: Enhance Vanilla Gameplay!
	-Feedback and Testing is Beneficial!
	-Detailed Notes for Individual Preference and Mod Learning!
		
	"The best mods rely on community involvement."
	
	
______________________________________________________________________________________________________________________
3.  Features
	*First, if you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
	

NEW FEATURES (version 1.5.1)
-Crafting Times more readable (Thank you Morph3usx for the specific orange color)
-Other "by the pixel" corrections


NEW FEATURES (version 1.4.1)
-Full Language Support
-See what icons are by putting the cursor over them on the display
-AGF version of color coding locked / jammed / empty loot. 

FIXES
-Compass is now accurate in following waypoints, etc.


•	CHATBOX IMPROVEMENT
	o	Chatboxes appear BEHIND other menu windows
	o	The background of the chatoutput disappears WITH the text for easier readability

•	BOTTOM LEFT STAT DISPLAY: HEALTH, STAMINA, FOOD, WATER, XP, LEVEL, OTHER
	o	Don't know what something is? Move your cursor over it and you will be told
	o	Compacting the HUD display for easier read of health, stamina, food, water, xp, level, and other stats
	o	Food and Water displayed in Percentage (If you want exact numbers, you need the Enhanced Patch)
	o	Other stats include elevation, player temp, and outdoor temp

•	FUEL BURNING TEXT DISPLAY IN WHITE
	o	Replaces the RED text of burning time to WHITE for easier readability	

•	COMPASS, DATE, TIME ADJUSTMENTS
	o	Compass is wider, easier to read, and has a mark for its center (It is now accurate!)
	o	Day and Time are moved to the left and right of compass for a more compact look
	o	Day and Time are now visible on menus	

•	TOOLBELT ADJUSTMENTS
	o	Toolbelt is lowered for more compact display and compatibility with other inventory mods
	o	Slots on toolbelt display which slot they are	
	
