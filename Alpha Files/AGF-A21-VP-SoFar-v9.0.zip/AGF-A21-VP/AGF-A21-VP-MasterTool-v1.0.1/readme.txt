VanillaPlus - MasterTool
A21 - Version 1.0.1


______________________________________________________________________________________________________________
***Requires VP-1Core, otherwise known as Vanilla Plus Core***


______________________________________________________________________________________________________________
MAIN Features:
-The Master Tool can do the work of an auger, chainsaw, knife, wrench, and nailgun combined, with minimal damage output.
-Can learn from the skill under intellect or find the schematic from tier 5 quests in hardened chests.
	-Infected Tier 4 hardened chests.
	-Infected Tier 5 hardened chests greater chance of finding it.


______________________________________________________________________________________________________________
If you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
	-All questions welcome from newcomers to seasoned 7d2d people.
	
	
______________________________________________________________________________________________________________
More Details about the author and other sites described on the README in the CORE modlet.