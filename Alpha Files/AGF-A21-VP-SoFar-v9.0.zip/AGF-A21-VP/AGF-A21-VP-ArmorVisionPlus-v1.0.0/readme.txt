VanillaPlus - Armor Vision Plus
A21 - Version 1.0.0


______________________________________________________________________________________________________________
***Requires VP-1Core, also known as Vanilla Plus Core***


______________________________________________________________________________________________________________
MAIN Features:
-Nightvision Goggles can now be turned into a mod to attach to your armor like the helmet light.
-Vision mods can now be attached to helmet and/or chest.
-Helmet Light now called Armor Light.
-Naturally discovered through traders and loot.


______________________________________________________________________________________________________________
If you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
	-All questions welcome from newcomers to seasoned 7d2d people.
	
	
______________________________________________________________________________________________________________
More Details about the author and other sites described on the README in the CORE modlet.