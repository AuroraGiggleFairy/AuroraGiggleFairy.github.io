Backpack72
A20 - Version 1.2.1
Description and Updates


______________________________________________________________________________________________________________________
README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Features


_____________________________________________________________________________________________________________________
1.  ABOUT AUTHOR
	-Name changed from RilesPlus to AuroraGiggleFairy (AGF)
	-Started playing 7d2d during Alpha 12
	-Started attempting to mod in Alpha 17
	-First published a mod during Alpha 18
	-Where to find:
		https://discord.gg/Vm5eyW6N4r
		https://auroragigglefairy.github.io/
		https://www.twitch.tv/AuroraGiggleFairy
		https://7daystodiemods.com/
		https://www.nexusmods.com/7daystodie
		
		
______________________________________________________________________________________________________________________
2.  MOD PHILOSOPHY
	-Singeplayer AND/OR Server-Side!
	-Goal: Enhance Vanilla Gameplay!
	-Feedback and Testing is Beneficial!
	-Detailed Notes for Individual Preference and Mod Learning!
	-Full Language Support (best I can.)
		
	"The best mods rely on community involvement."
	
	
______________________________________________________________________________________________________________________
3.  Features
	*First, if you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r


REVISTED my first backpack mod of 72 slots! 
Due to its popularity and my experimenting with 60, 72, 84, and 96 slots, I have decided to return to 72.

My new years of modding experienced has been applied to this early mod of mine. :-) Makes me sooo happy.


-FULL LANGUAGE SUPPORT
-72 Slot Backpacks
-Updated encumbrance slots, buffs, and perks.
-Slightly reduced the encumbrance effect on mobility (move speed).
-Added in the lockable slots in an orientation I prefer.
-Added notes for modders or modders-to-be to see what I did code wise.


THANKS TO ALL WHO SUPPORT ME! :-)