HUDPlus Addon
A20 - Version 1.5.0
Description and Updates


____________________________________________________________________________________________________________
***REQUIRES HUDPlus to work, as this is an ADDON.***

***REQUIRES EAC to be turned off.***

***NOT SERVER SIDE, must be installed on BOTH server and clients***


______________________________________________________________________________________________________________
MAIN Features:
	-Food and Water displays both amount and percentages.
	-XP to Next Level and Lootstage is displayed.
	-On the chat output you can see zombie kills, player deaths, and pvp kills.

	
______________________________________________________________________________________________________________
If you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
	-All questions welcome from newcombers to seasoned 7d2d people.
	


