HUDPlus - HealthBars
7d2d V2 - v4.0.0


______________________________________________________________________________________________________________________
README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Installation and Removal Notes
4. Features
5. Change Log


_____________________________________________________________________________________________________________________
1.  ABOUT AUTHOR
	-My name is AuroraGiggleFairy (AGF), previously known as RilesPlus
	-Started playing 7d2d during Alpha 12
	-Started attempting to mod in Alpha 17
	-First published a mod during Alpha 18
	-Where to find:
		https://discord.gg/Vm5eyW6N4r
		https://auroragigglefairy.github.io/
		https://www.twitch.tv/AuroraGiggleFairy
		https://7daystodiemods.com/
		https://www.nexusmods.com/7daystodie

		
______________________________________________________________________________________________________________________
2.  MOD PHILOSOPHY
	-Preferably easy installation and use!
	-Goal: Enhance Vanilla Gameplay!
	-Feedback and Testing is Beneficial!
	-Detailed Notes for Individual Preference and Mod Learning!
	-Full Language Support (best I can.)
		
	"The best mods rely on community involvement."


______________________________________________________________________________________________________________________
3.  INSTALLATION and REMOVAL NOTES
	*First, if you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
		-All questions welcome from newcombers to seasoned 7d2d people.

	***Requires the Main HUDPlus mod, as this is an optional addon to it.***

	-This is a server-side mod, meaning this mod can be installed on JUST the server and will work automatically for joining players.
	-Works with EAC on or off.
	-All 14 languages supported
	-HUDPlus - Healthbars is SAFE to install on new or existing games.
	-HUDPLus - Healthbars is SAFE to remove from an existing game.


______________________________________________________________________________________________________________________
4.  FEATURES

	-Adds enemy health bars with an AGF style.


______________________________________________________________________________________________________________________
5.  CHANGELOG
v4.0.0
-Corrected that "isBoss" is at the same height
-Added functionality to ensure it is standalone and works conditionally with my other HUD features.

v3.0.0
-It was WAY too small and other blatant issues I hadn't addressed yet.
-NOW should be easier to read!

v2.0.0
-Updated to 7d2d Version 1.0.

v1.0.0
Just made it.