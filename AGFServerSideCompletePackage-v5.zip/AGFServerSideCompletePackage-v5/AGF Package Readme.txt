AGFServerSideCompletePackage-v5

____________________________________
AGF-A21Backpack84Plus1.2.9
	-84 Slot Backpack, with 3 rows of encumbrance  slots (36 slots)
	-Updated encumbrance slots, buffs, and perks. PackMule does free up all 36 slots.
	-Reduced encumbrance effect on mobility (move speed) to prevent immobility when fully encumbered and with heavy armor.
	-Lockable slots included.
	
____________________________________
AGF-A21HUDPlus1.9.3
	-Compact and readable display of health, stamina, food, water, level, xp, elevation, and temperature.
	-Wider and accurate compass with a center mark.
	-Lowered toolbelt for backpack mod compatibility and added slot numbers.
	-Improved readability of the chat output when sending and receiving messages.
	-Map information moved to its own section next to the map with labels.
	-Crafting and burning times adjusted for easier viewing.
	-Date, Time and Skulls displayed on all menus.
	-Viewing quest selections made easier with improved background, color, and poi_names.
	-Simple color coordination of interactive blocks or npcs.
	-5 crafting slots positioned evenly.
	-Removed Pop up of wandering into new location.
	-Simplified location name viewing.
	
____________________________________	
AGF-A21HUDPlus-HealthBarsv1.0.0
	-Adds enemy health bars with an AGF style.

____________________________________
AGF-A21HudPlus-SkullsOnHudv1.0.0
	-Enables showing the skulls under the name of the location, but with the AGF Hud style.
	
____________________________________	
AGF-A21-VP--1CORE-v1.3.9
	MAIN Features:
	-Build any door with the simplified wood, iron, steel/vault, and powered variants.
	-See all your crafting levels all on one page!
	-Rebundle Bundles: Things opened from a bundle can be crafted back into one.
	-Mining Perk now also bundles clay, sand, and brass.
	-(English Only) Naming Scheme for better sorting.
	
	OTHER Features:
	-All Archery Uses Feathers: This is for simplification, also feathers can be crafted from plastic.
	-Cobblestone Variant Block also craftable directly from clay and rock.
	-The sand you get from mining very slightly increased.
	-First Aid Bandage also craftable directly from aloe cream and a bandage.
	-Fix for car salvaging issue when you do too much damage.
	-Repair blocks that were originally unrepairable (find more, let me know!)
	-Armors now show up in crafting lists without having to search for them.
	-Bundles have a color tint for additional visual differentation.
	
	ADMIN/MODDER Features:
	-Admin Tools: Block Replace Tool can replace blocks quickly.
	-Admin Tools: Books that give a set amount of xp to a player.
	-Modding Blocks: A butcher block and salvage block for harvest testing.

____________________________________
AGF-A21-VPC-AmmoPlus-v1.0.1
	-Ammo Stacks adjusted to be more simpler in consistency (matches stack size modlet)
	-Scrapping Ammo gives you bundles to open with all their ingredients.
	-Got a lot of Scrapped Ammo Bundles? Consolidate your scrapped bundles into more conscise bundles so players don't
	  have to click "open" for each piece of ammo. Consolidate into 100 or 1000.
		
____________________________________		
AGF-A21-VPC-ElectricityPlus-v1.0.4
	-Electrical banks expanded, requiring less to be needed. Helps performance.
	-Engines, batteries, and solar cells stack together and no longer have qualities.
	-Power Cores are now used inside the electrical banks to prevent stealing and other glitches.
	-A "Chargeable" power core is used in place of batteries, crafted from power cores.
	-Solar Banks are craftable at level 85 of electrician.

____________________________________	
AGF-A21-VPC-FarmingPlus-v1.1.0
	-Tier 3 of Living Off the Land allows you to craft plantable birdnests and bee hives (bee flower).
	-Tier 3 of Living Off the Land reduces ingredients to make a seed from 5 to 3.
	-Naturally discovered through traders and loot.
	
____________________________________	
AGF-A21-VPC-SimplifiedStackSizes-v1.1.1
	-Simplified stack sizes that keeps close to vanilla experience.
	-Bundles and consumables stack to 50
	-Ammo stacks to 500
	-Resources are generally 500, 1000, or 6000
	-Gas, Coins, and plant fibers stack to 30000
	-Placeable blocks (like workstations) to 500
	-Farming and General blocks to 5000
	-Opening bundles adapted to new stack sizes
	
____________________________________	
AGF-A21-VPC-SmeltingPlus-v1.0.0
	-Forges have 3 slots with text nicely centered.
	-Sand smelts at same ratio as rocks and clay, 1 to 5 (default was 1 to 4).
	-Manage your sand, rock, and clay by crafting/smelting a single nugget (for us OCD folk, lol!)

____________________________________
AGF-A21-VPC-Tier6Crafting-v1.0.1
		-Obtaining tier 4 of a perk related to items, you gain a +1 overal crafting level due to your familiarity with them.
	
____________________________________	
AGF-A21-VPS-ArmorVisionPlus-v1.1.0
	-Nightvision Goggles can now be turned into a mod to attach to your armor like the helmet light.
	-Vision mods can now be attached to helmet and/or chest.
	-Helmet Light now called Armor Light.
	-Naturally discovered through traders and loot.
	-Can bundle the nightvision mod for hoarding purposes.

____________________________________
AGF-A21-VPS-AutomobilesRespawn-v1.0.3
	-Vehicles that are salvaged leave an upright car seat to visualize where it will respawn.
		Destroy the upright seat and it will not respawn.
		An on screen tip will appear after salvaging to inform players that it will respawn.
		Respawn set at 10 real life hours. Editable on the blocks.xml.
	
____________________________________	
AGF-A21-VPS-BattleAxeMod-v1.1.0
	-A mod for axes that increases entity damage but reduces block damage.
	-Naturally discovered through traders and loot.
	-You can now bundle this mod for hoarding purposes.
	
____________________________________
AGF-A21-VPS-BetterEggChance-v1.0.0	
	-Chance to find eggs in a birdnest increased from 35% to 63%.
	
____________________________________	
AGF-A21-VPS-BookCollections-v1.0.0		
	-When you read all 7 books of a volume, you can then combine the 7 books into one.
	-You can also combine EVERY book into one.
	-Reading the combined items will unlock all the included readings stated in them.
	-Combined books sell for more.
	-Useful for Admins needing to help people regain read books.
	-Just for funsies in collecting entire book series.	

____________________________________	
AGF-A21-VPS-BundleMods-v1.0.0	
	-Mods can be bundled to save storage space.
	
____________________________________	
AGF-A21-VPS-CompactTrees-v1.0.0
	-Planting less trees helps performance, now create a compact tree. 1 tree that acts like 5.
	
____________________________________	
AGF-A21-VPS-CosmeticMods-v1.1.0
	-Instead of having to find them, you can now craft cosmetic mods. (Like the ball cap for your helmet.)
	-More than the original hat options are now included to allow completing full suits while wearing armor.
	-Some of the cosmetic mods are for the face, gloves, and boot slots.
	-Facial Piercings are back.
	-Mods can now be crafted into bundles for easier hoarding.
	
____________________________________	
AGF-A21-VPS-DeathPenalty10Percent-v1.0.0
	-Each death penalty is 2.5% up to a max of 10%, instead of 25% up to 50%.
	
____________________________________	
AGF-A21-VPS-DecorationBlock-v2.0.4
	-Over 3,500 in game models all within one block!
	-Craft at a workbench.
	-Levels in perkAdvancedEngineering slightly reduces ingredient costs.
	-If the block is normally a container, it is secured in its deco version size (10 x 10)
	-Strong as Wood Blocks (500hp), but high explosive resistance.
	-When a player breaks one, it returns to their inventory.
	-When blocks break to falls, zombies, or explosions, high chance of picking it up shortly after.
	-HIGH COMPATIBILITY as it only adds its own code and NOT dependent on existing ones.
	-If it is a light, it can be powered with electricity.
	
____________________________________	
AGF-A21-VPS-DewsPlus-v1.1.4
	-Compile 5 dew collectors into 1 that acts like 5
	-Dew Collectors are now sized 2x2 instead of 3x3
	
____________________________________	
AGF-A21-VPS-DrawbridgeAnyAngle-v1.0.0
	-The drawbridge may no be placed in other directions like sideways, upside down, etc.
	
____________________________________	
AGF-A21-VPS-DrinkableAcid-v1.0.0
	-Drink ACID for some interesting effects.
	-Likely will kill you (~120hp damage).
	
____________________________________	
AGF-A21-VPS-DyesPlus-v2.0.2
	-Easily interchange dye colors:  A.SCRAP any dye to get 15 paint.  B.CRAFT any dye with 15 paint.
	-Added 28 Colors with simple naming scheme.
	-Added Invisible Dye that can hide a worn item.
	
____________________________________	
AGF-A21-VPS-FuelPlus-v1.0.0
	-Combine wood or coal into single items with longer burn times; follows default times.
	-Comes in 10 minutes, 60 minutes, or 600 minutes.
	
____________________________________	
AGF-A21-VPS-HPRunningSolesMod-v1.1.0
	-Create the HP Running Shoes but as a mod for your boots.
	-Naturally discovered through traders and loot.
	-You can now bundle this mod for hoarding purposes.
	
____________________________________	
AGF-A21-VPS-JunkTurretPlus-v1.0.0
	-Each tier in perkTurrets increases magazine capacity by 50, up to 250 instead of by 10, up to 50.
	
____________________________________	
AGF-A21-VPS-LanternPickupPlus-v1.2.0
	-Lanterns, Burning Barrels, Flashlight, and Jack-o-Lanterns can be picked up.
	-Lanterns and Flashlights are in a single block that you can select different variants from.
	
____________________________________	
AGF-A21-VPS-LargerHordes-v1.0.0
	-I enjoy being visited upon by larger hordes, with minimal performance hits.
	-I increased the animal hordes only by a little.
	
____________________________________	
AGF-A21-VPS-MacheteFasterMod-v1.0.0
	-A mod for machetes that make it swing as fast as hunting knife, when attached.
	-Naturally discovered through traders and loot.
	-You can now bundle this mod for hoarding purposes.
	
____________________________________	
AGF-A21-VPS-MasterTool-v1.1.1
	-The Master Tool can do the work of an auger, chainsaw, knife, wrench, and nailgun combined, with minimal damage output.
	-Schematic has an 11% to be found in T5 quest loot, but a 27% chance in T6 quest loot.
	-Miner69r increases the block damage of the tool.
	-Mother Lode, Salvage Operations, and Living Off the Land increases the appropriate harvest amount (not block damage).
	-The harvesting amount of the master tool ties with other tools.
	
____________________________________	
AGF-A21-VPS-MaxLevel500-v1.0.0
	-Simply just raises the max level cap from 300 to 500... For funsies.
	
____________________________________	
AGF-A21-VPS-Mod988-v1.0.0
	-Simply replaces the noose with plain rope.
	-This is done for mental health purposes.	
	***Suicide Hotline is 988***	
	
____________________________________	
AGF-A21-VPS-ModSlotsPlus-v2.0.2
	-When going from stone to iron or iron to steel, you do not lose any mod slots.
	-General increase on the minimum mod slots end.
	-Tier 6 of best items can have 6 slots.
	*Note, these changes only apply to items you find/craft going forward from installation.*
	
____________________________________	
AGF-A21-VPS-PaintbrushPlus-v1.0.0
	-Painting costs ZERO paint.
	-You can hold down the trigger to continue painting.
	-Painting distance is reduced to prevent accidental long distance painting.

____________________________________
AGF-A21-VPS-PlayerResetQuests-v1.0.0
	-When speaking with a trader, players can choose for the quest list to regenerate
	
____________________________________	
AGF-A21-VPS-ProgressiveBiomeSpawning-v1.1.0
	-Progressive Biome Spawning Increase,
		-Forest is a bit easier now due to increase timid animals.
		-Desert to Snow to Wasteland, wasteland at night is now a nightmare.
	-The point? Gives a server something for newcomers and pros alike.
	
____________________________________	
AGF-A21-VPS-PumpkinsPlus-v1.2.0
	-Throw pumpkins that explode like molotovs.
	-Wear a pumpkin on your head!
	-Wear a pumpkin as a cosmetic mod on your helmet!
	
____________________________________	
AGF-A21-VPS-QuickStart-v2.0.0
	-Starting in game simply gives you the equipment, skill points, xp, and quest to trader right at the start.
	
____________________________________	
AGF-A21-VPS-ScrapBattery2Acid-v1.0.0
	-When you scrap a battery, you get an Acid instead of lead.
	
____________________________________	
AGF-A21-VPS-StayLongerAnimalCorpse-v1.0.0
	-Animal Corpses stick around for 10 minutes instead of 5 minutes.
	
____________________________________	
AGF-A21-VPS-StayLongerPlayerBackpack-v1.0.0
	-Player's backpacks stick around for 5 hours instead of 1.
	
____________________________________	
AGF-A21-VPS-StayLongerZombieLoot-v1.0.0
	-Zombie loot sticks around for 1 hour instead of 20 minutes.
	
____________________________________	
AGF-A21-VPS-StorageSizesPlus-v1.0.1
	-Storage Box now 64 slots instead of 48
	-Storage Containers and Gun Safes now 100 slots instead of 72
	*Note, these changes only apply to blocks you find/craft going forward from installation.*	
	
____________________________________	
AGF-A21-VPS-TacticalRiflePlus-v1.0.0
	-For Tactical Rifle, removed 3 round burst and slighty increased magazine size.
	
____________________________________	
AGF-A21-VPS-Tires2Wheels-v1.1.0
	-To make wheels, you can either use Acid or good used tires you have found.
	-20% chance of getting a full wheel or tire from destroying them found in the world.
	-You can also scrap the tires for plastic.

____________________________________
AGF-A21-VPS-ToolImprovements-v1.1.1
	-Ratchet salvaging speed slightly faster, impact drill slightly more.
	-Claw Hammer repairs slightly faster.
	-Chainsaws now butcher harvest 70% resources like the axes.
	
____________________________________	
AGF-A21-VPS-TraderAlwaysOpen-v1.0.0
	-Traders are always open.
	
____________________________________	
AGF-A21-VPS-TraderVendingMachine-v1.0.1
	-High trader stage unlocks option to purchase trader managed vending machines.
	*Trader managed vending machines are the ones that come with food and drinks that reset daily.
	
____________________________________	
AGF-A21-VPS-VehicleDisassembly-v1.0.0
	-At a workbench, you can craft a vehicle into a disassembled bundle to recollect its parts.
	-Note: instead of a battery, you get an acid.

____________________________________
AGF-A21-VPS-VehiclePerformance-v2.0.0
	-Vehicles Max Speed Increased
	-Breaking Power increased
	-Easier traversing on mountain terrain
	-Gyrocopters can reverse with more speed
	-Better handling for vehicles with only 2 wheels
	-Doubled Vehicle Hitpoints to account for increased collision damage due to increased speeds
	
____________________________________	
AGF-A21-VPS-VehicleSafeAircraftJumps-v1.0.1
	-For accidental and intentional exiting of vehicles, you are safe from fall damage for at most 8 seconds.
	
____________________________________	
AGF-A21-VPS-VehicleSeating-v1.0.0
	-Additional vehicle seats are now default, as in you don't have to use the expanded seat mod.
	-5 seats in the truck. (I'm personally annoyed with how they did the 4 seats since it looks crap and I had 5 since A18.)
	-Gyrocopter seats 4.... pretty funny how.
	-Like the minibike and motorcycle, bicycles now seat 2... closely...

____________________________________
AGF-A21-VPS-VehicleStorageSizes-v1.0.0
	-Adds 1 row of storage to each vehicle.
	
____________________________________	
AGF-A21-VPS-VehicleUseLessGas-v1.0.0
	-Keeping fuel tanks at default size, making the gas last for larger distances (without vehicle mods):
		Gyrocopter: 32km instead of 12km
		Minibike: 32km instead of 16km
		Motorcycle: 48km instead of 24km
		4x4Truck: 60km instead of 40km
	-This mod does not increase fuel tank size, just reduces how much gas is used to travel these distances
	
____________________________________	
AGF-A21-VPS-ZombieCorpseLeaveQuicker-v1.0.0
	-For performance purposes, Zombie corpses disappear after 10 seconds instead of 30.