AGF-HUDPlus-1Main
7d2d Version 3
Version: 6.4.0  
Download: https://github.com/AuroraGiggleFairy/AuroraGiggleFairy.github.io/raw/main/04DownloadZips/AGF-HUDPlus-1Main.zip

 > Thanks Stroichik for detailed bug report about 6.2.0's forge problem.

========================================

========================================

README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Need Help?
4. Install Scope & EAC Requirement
5. Compatibility
6. Features Summary
7. Features Details
8. Changelog
9. Install Scope & EAC Requirement Guide
10. Installation Guide
11. Removal Guide
12. Update Guide
13. Backup Guide

========================================

========================================

1. About AGF
- AuroraGiggleFairy (AGF) creates accessibility-focused, vanilla-enhancing mods for 7 Days to Die.
- Goal is to deliver practical, easy-to-use features shaped by community feedback.
- Main site and first release source: auroragigglefairy.github.io: https://auroragigglefairy.github.io/
- Discord is best for latest updates, fastest contact, and becoming a tester: discord.gg/Vm5eyW6N4r: https://discord.gg/Vm5eyW6N4r

========================================

========================================

3. Need Help?
- AuroraGiggleFairy is available via Discord: https://discord.gg/Vm5eyW6N4r
- All questions welcome from newcomers and seasoned players alike.

========================================

========================================

4. Install Scope & EAC Requirement
- Server-Side (EAC-Friendly): Server install works for all joining players; EAC on or off.

========================================

========================================

5. Compatibility
- Last 7d2d Version tested on: 3
- "AGF-HUDPlus-1Main" is SAFE to install on an existing game.
- "AGF-HUDPlus-1Main" is SAFE to remove from an existing game.
- Unique Details: None

========================================

========================================

6. Features Summary

- Makes the HUD and menus easier to read.
- Improves layout for compass, toolbelt, map, trader windows, chat, and timers.
- Adds quick visual hints: clearer slot markers, color hints, centered crafting slots, and always-visible date/time/location.
- See this mod's README for full details.

========================================

========================================

7. Features Details

- Works standalone.
- Displays health, stamina, food, water, level, XP, and elevation in a compact, easy-to-read format.
- Lockable inventory slots are clearly marked for quick identification.
- Compass is wider and features a visible center mark.
- Toolbelt is lowered for better backpack mod compatibility, with numbered slots for convenience.
- Chat messages are easier to read with updated backgrounds.
- Map details are displayed in a dedicated section beside the map, with clear labels.
- Crafting and burning timers are visually clearer and easier to read.
- Date, time, outdoor temperature, and the location display are visible on all menus.
- Storm visual alerts now appear below the location display, freeing space for other mods.
- Trader dialogue, including quest selection, is easier to read with updated backgrounds.
- Simple color-coding for interactive prompts (the text that appears when looking at loot, workstations, etc.) for quick recognition.
- Centered crafting slots.
- Schematics, magazines, and books are color-coded to show whether they have been read.
- The NoEAC-EnhancedAGF provides even more visual features if also installed.
- Vehicle stats display has been updated for clearer, easier at-a-glance reading.
- AGF visual style for Health Bars when activated.
- Compatible with all 7 Days to Die versions since 2.5. (For new game updates, check for the latest HUDPlus version if needed.)

========================================

========================================

8. Changelog

v6.4.0
- Updated to work with new features in EnhancedAGF and compatibility patch for DishongTowerChallenge.

v6.3.1
- Visual fix on in menu day/time.

v6.3.0
- MAJOR ERROR fix, 5th crafting slot no longer xml capable, causes many errors.
- Localization correction.
- Removed weird files.

v6.2.0
- Now supports ScreamerAlert mod!

v6.1.0
- Added support between AGF HUDPlus and AutoRun.
- Brought the conditional of HUDPlus with toolbelt 12 slots to this windows.xml.

v6.0.4
- Updated image file.

v6.0.3
- Healthbar style now part of 1Main.

v6.0.2
- Updated health/stamina bar appearance for now.
- Updated a few EnhancedAGF updates for hud for 7d2d v3.0
- A few other corrections to incorporate a few options. 

v6.0.1
- Updated Localization columns.

v6.0.0
- Updated for 7d2d v3.0.
- Removed previous 7d2d version support.

v5.4.7
- Further References updates.

v5.4.6
- ReadMe Format Update.

v5.4.5
- Edits due to a rename of EnhancedPatch to EnhancedAGF.
- Update 1 of 2, that includes extra Vehicle stats in it's own form.

v5.4.4
- Updated backpack references due to name change.

v5.4.3
- Updated conditional for my ItemTypeIconColor mod.

v5.4.2
- Updated the references to new naming scheme CORRECTLY.

v5.4.1
- Updated references to new naming scheme for enhanced patch.

v5.4.0
- Updates for automating the publishing of this mod.
- Updated storm alerts location.
- Updated to integrate new NoEAC AGF mods.

v5.3.2
- Updating some names for sections in the code for better compatibility and modding.

v5.3.1
- Enhanced Patch and Death Screen no longer show after death.

v5.3.0
- Enhanced Patch xml code is within the HUDPlus, allowing for a unique situation:
- If server has my HUD, anyone joining will enjoy the HUD.
- If server has EAC turned off and a player joining has enhanced patch locally installed, they will enjoy the enhanced HUD.
- Clarification: Enhanced Patch does NOT have to be installed on server, just the HUD and EAC off.
- No one will be required to download anything, only optional if they want the extra features.
- Enhanced patch offers cold resist, heat resist, core temp, elevation, loot stage, used inventory slots, armor, explosion resist, crit resist, entity / block damage with current equipped item, and mobility.

v5.2.2
- Added simple color interactions for Apiary.

v5.2.1
- Expanded trader response box to account for extra quest options.

v5.2.0
- Updated to allow working with 7d2d version 2.5. (Still works with versions 2.0 through 2.4)

v5.1.0
- Updated method of checking if someone has the "enhanced patch" installed or not.
- The coding changes of the enhanced patch at now within this file's code.
- When showing the amounts of food or water, also shows the max amount to be considered full.
- Removed the excess files in early attempt at utilizing the new conditional system.
- Finally removed the stats that display while on the death screen.
- The location/skulls in the menus, its background was light grey instead of dark.

v5.0.2
- Added conditional for my new backpack option.

v5.0.1
- Left out a conditional format associated with storages and my backpacks conflicting. Now fixed.

v5.0.0
- Localization fixes
- Updated to utilize conditional formatting (big deal!).
- Updated to account for version 2.2 regardless if you are using 2.2 or 2.1.
- Significant simplification and re-orginization of Main Hud, addons and options.
- Purple Book is now standalone along with several other features in their own modlets.
- Default keeps the POI Entered popup. (There is now an optional remove modlet)
- Default keeps the written weather alert. (There is now an optional remove modlet)

v4.1.2
- Added the new/missing stage loot cap icon under the location markers.
- Fixed that chat input section when your message is more than one line to maintain the background.
- Lots of visual errors and missplaced backgrounds/borders in purple book, even some things that were 1 pixel off.....
- Updated the text about what to click to zoom in, for the magazines and armors.
- When zoomed into magazines, the ones that are finished now maintain the green background when completed.
- Under Armors, updated the sneak effectiveness numbers as they were buffed in v2.0.
- Updated the descriptions of some of the armors.
- Added more details in zoomed armors that are needed, like what are "fitness" items.
- Quest selection window, wasn't tall enough.... fixed.

v4.1.1
- Renamed a bit hopefully for better understanding the difference between one with or without purple book.

v4.1.0
- Updated for V2!
- Had to rework aspects of purple book due to more stable "button" system.
- Fixed an error since the inception of Purple Book, lol.
- Purple book's "zoom in feature" are now buttons in a header to easily swap between them.

v4.0.0
- Found missing translations
- Completed the Zooming in features For crafting list and armors. (along with adapting my mods that effect these.)
- Lots of corrections and cleaning up of both UI of the purple book AND in the xml code.
- Edited parts of code to be display changes to checklist made by any updated AGF mods.

v3.5.0
- centered a few things that I can't believe weren't centered long ago!!!
- Added under the purple book's tab, a row showing the completed books series for easier finding the cursor's spot for tooltip
- Updated information in the purple book's header to encourgae using cursor hover OR clicking to zoom where apprioriate

v3.4.0
- Made some minor adjustments to a few things
- Made some of the hard edges of my sections with a squared background have curved corners
- Changed the Elevation Icon
- Other changes are related to compatibility with additional HUD options
- A zoom in feature of the Armor's Tab!!!

v3.3.4
- Fixed the buff pop up section, where other languages it would go over the icon. (Just Vanilla Code, now updated to changes fun pimps made)

v3.3.3
- Under the crafting checklist, workstation section background goes green when maxed out, appropriately.
(Thanks Snakie)

v3.3.2
- Organized the code for the checklist (purple book)
- On the Armors Tab, I rearranged armor types of light, medium, and heavy in alphabetical order
- Added specific names to specific entries of checklists so that Master Tool will be compatible

v3.3.1
- Added some naming scheme for crafting list, to make compatible with other VP mods of mine.

V3.3.0
- Updated for V1.1.
- Stealth is updated
- Rogue and Assassin outfit's sneak effectiveness updated on Armor Tab
- Electrical magazine crafting unlocks updated on Crafting Tab

v3.2.2
- Correct Localization issues where a few were placed in a different mod of mine... facepalm LOL!

v3.2.1
- Fixed an error that would occur when you have more than 3 shared waypoints in your shared list.

v3.2.0
- Crafting Checklist now visually indicates where you are with crafting levels.

v3.1.1
- Finished the armor page
- corrected some checklist checking, thought it wasn't running up performance. I had put the wrong value in, now fixed!

v3.1.0
- Modified the altIconType color for read books to be green with slight transparency.

v3.0.0
- Added a "purple book" icon to show magazines on one page
- books on one page
- unlocks on one page
- and armor details

v2.1.0
- updated for V1.0(b325)
- Lockable slots system updated with easier visuals
- Added another dew collector interaction prompt I missed.

v2.0.3
- fixed the remaining interaction prompts for dew collectors
- added one I missed

v2.0.2
- fixed the show time twitch integration thingy.

v2.0.1
- Added the missing interaction prompts for dew collectors... But in beta, not all languages are present.

V2.0.0
- Updated for 7d2d Version 1.0
- Instead of making a separate addon, placing the skulls/location as part of the compass area.
- Added the "sprinting" notification
- Keeping the vanilla location/skulls box in place

V1.9.3
- Added the date and time while speaking with a trader.

v1.9.2
- The word "level" no longer disappears permanently when using the F7 key.
- In the menu display of skulls, if it was only biome skulls, they were tiny. Now they are the right size.
- Started tracking changes

========================================

========================================

9. Install Scope & EAC Requirement Guide

========================================

This guide explains where to install a mod and whether it is EAC friendly.

========================================

A. Install on Server, Client, or Both?
  - Server - where the game is hosted. This could be your own PC if you are hosting the game yourself, or a game hosting service like Pingperfect.
  - Client - your own PC.
- Some mods only need to be in one place. Others need to be in both. Please see the Mod Types section below for exact requirements.

========================================

B. EAC Friendly?

- EAC stands for Easy Anti-Cheat. It's a program built into 7 Days to Die that helps protect multiplayer sessions from cheating.
- Mod Type 1 is EAC friendly. Mod Types 2, 3, and 4 require EAC to be turned off.
- Running without EAC opens up a wider range of mods and experiences. If you're running a multiplayer server without EAC, here are some good practices to keep things running smoothly:
  - Recommended practices when running multiplayer with EAC off:
    - Require a password and be conservative in distributing it.
    - There are tools available such as ALOC and Server Tools to add extra protections.
    - Optionally, require the whitelist system for the strictest limitation on who can join.
    - Seek out other server hosts and discuss what they do.
    - You can find help on AGF's Discord: DISCORD: https://discord.gg/Vm5eyW6N4r

========================================

C. Mod Types

| # | Mod Type | What It Means |
|---|----------|---------------|
| 1 | Server-Side (EAC-Friendly) | Server install works for all joining players; EAC on or off. |
| 2 | Server-Side (EAC Off) | EAC off required; server install works for all joining players. |
| 3 | Server/Client-Side (Required) | EAC off required; host and joining players must install it. |
| 4 | Client-Side (Only) | EAC off required; server install has no effect; only the installing player gets the feature. |

========================================

========================================

10. Installation Guide

========================================

⚠️ IMPORTANT ⚠️ Make a BACKUP!
- If you are making changes to an existing game, ALWAYS make a backup first.
- (See the backup instructions further below.)

========================================

A. Special Note
- The mod named "0TFPHarmony" is REQUIRED and should never be removed.
- If it is missing, you can restore it by verifying your installation:
   - In Steam, right click on 7 Days to Die
   - Select "Properties"
   - Select "Installed Files"
   - Click on "Verify integrity of game files" and wait for completion.

========================================

B. Install to Your PC (Singleplayer, Hosting Friends, or Client-Required Mods)
1. In Steam, right click 7 Days to Die
2. Select Manage, then Browse local files
3. Open the Mods folder
4. Extract the mod into this Mods folder
   - Final folder should look like: Mods//ModInfo.xml
   - If the zip creates an extra parent folder, move the mod folder up one level
5. Keep 0TFPHarmony in this folder
   - It comes with the game and should remain in Mods

========================================

C. Install to a Dedicated Server (hosted sites or player-run)
1. Find the main server folder
   - If using a hosted site, use their file manager or a program like FileZilla
2. Open or create the Mods folder
3. Extract the mod into this Mods folder
   - Final folder should look like: Mods//ModInfo.xml
   - If the zip creates an extra parent folder, move the mod folder up one level
4. Fully restart the server after install

========================================

========================================

11. Removal Guide

========================================

⚠️ IMPORTANT ⚠️ Make a BACKUP First!

========================================

A. Special Note
- The mod named "0TFPHarmony" is REQUIRED and should never be removed.
- If it is missing, you can restore it by verifying your installation:
   - In Steam, right click on 7 Days to Die
   - Select "Properties"
   - Select "Installed Files"
   - Click on "Verify integrity of game files" and wait for completion.

========================================

B. How do I remove mods?
- The safest approach is to only remove mods when starting a new game.
- ALSO smart to make a backup of the game (see below for instructions if needed).
    - If you remove a mod that added new items or features, characters and/or the map may reset, or become permanently unplayable.
    - If you are unsure, check the mod's readme for specific removal notes or ask in AGF's DISCORD: https://discord.gg/Vm5eyW6N4r.
- To remove, simply locate the mod folder and delete it. All done!

========================================

========================================

12. Update Guide

========================================

⚠️ IMPORTANT ⚠️ Make a BACKUP First!

========================================

A. Special Note
- The mod named "0TFPHarmony" is REQUIRED and should never be removed.
- If it is missing, you can restore it by verifying your installation:
   - In Steam, right click on 7 Days to Die
   - Select "Properties"
   - Select "Installed Files"
   - Click on "Verify integrity of game files" and wait for completion.

========================================

B. Updating individual AGF Mods
1. Shutdown the game.
2. Make a backup. (instructions below)
3. Install the new version as usual. (see above)
4. Delete the older version.
   - In your Mods folder, you will see two folders for the mod, each with its version number.
5. THEN you may turn the game back on.

========================================

C. Updating entire AGF Pack
1. Shutdown the game.
2. Make a backup. (instructions below)
3. Carefully delete all AGF mods. (don't forget the zzzAGF mod)
4. Install the new package as usual. (see above)
5. THEN you may turn the game back on.

========================================

========================================

13. Backup Guide

========================================

Having multiple backups are best when experimenting or hosting.

========================================

A. Backing Up Your Singleplayer or Local Game
1. Open "Run" (Windows key + R)
2. Type %appdata% and click OK
3. Open the "Roaming" folder
4. Open "7DaysToDie"
5. Open "Saves"
6. Find your World Name folder (e.g., "Navezgane")
   - You can check your world name in the game's "Continue Game" or "Join Server" menu.
7. Select your Game Name folder (inside the World Name folder)
   - The Game Name is also shown in the game menus.
8. Copy the entire Game Name folder and paste it somewhere safe
   - (like your Desktop or another safe location).

========================================

B. Dedicated Server Game
1. Open the server's "Saves" folder
   - Its location varies by host, but it's typically somewhere in the main dedicated server folder.
   - If you cannot find it, check your host's documentation or ask support.
2. Find your World Name folder (e.g., "Navezgane")
   - You can check your world name in the game's "Join Server" menu or "Server Config".
3. Select your Game Name folder (inside the World Name folder)
   - The Game Name is also shown in the game's "Join Server" menu or "Server Config".
4. Copy the entire Game Name folder and paste it somewhere safe
   - (like your Desktop or another safe location).

========================================

C. To Restore a Backup
- Keep your backup until you're sure everything works!
1. Undo any mod changes
2. Delete the current Game Name folder (in "Saves")
3. Move your backup folder back into "Saves"

========================================

========================================