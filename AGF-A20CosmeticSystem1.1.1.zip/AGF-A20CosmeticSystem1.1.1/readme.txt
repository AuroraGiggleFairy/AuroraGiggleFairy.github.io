CosmeticSystem
A20 - Version 1.1.1
AuroraGiggleFairy (AGF)
https://discord.gg/Vm5eyW6N4r


INSTALATION NOTES
1. SAFE for NEW and EXISTING games
2. Other mods may cause conflict, contact AGF on Discord

UN-INSTALATION NOTES
NOTE: IF removing from a game you used this mod in, likely have issues on that saved game
1. Delete this mod's folder



FEATURES
-Works Server Side and is EAC Friendly
-Full Language Support
-Improved Painting (No Paint Required, Hold Trigger to keep Painting, Paints only distances within Reach)
-Craft Nightvision Mod to go into helmet or chest armors
-Helmet Light Mod may go into helmets or chest armors
-High Performance Running Soles Mod for armored boots (will NOT work with Impact Bracers)
-Craft and Bundle Dyes
-Orange Dye
-Invisible Dye (to visually hide apparel)
-Craft Cosmetic Mods (place in armors to wear full outfits)


_____________________________________________________________________________________________________________________
ABOUT AUTHOR
-Name changed from RilesPlus to AuroraGiggleFairy (AGF)
-Started playing 7d2d during Alpha 12
-Started attempting to mod in Alpha 17
-First published a mod during Alpha 18

WHERE TO FIND
https://discord.gg/Vm5eyW6N4r
https://7daystodiemods.com/
https://www.nexusmods.com/7daystodie
https://www.twitch.tv/AuroraGiggleFairy
		
MOD PHILOSOPHY
-Singeplayer AND/OR Server-Side!
-Goal: Enhance Vanilla Gameplay!
-Feedback and Testing is Beneficial!
		
"The best mods rely on community involvement."
	

