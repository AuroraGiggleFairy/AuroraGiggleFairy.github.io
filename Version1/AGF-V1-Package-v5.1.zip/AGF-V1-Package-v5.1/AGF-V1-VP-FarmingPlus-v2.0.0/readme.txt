VanillaPlus - FarmingPlus
V1.0 - Version 3.0.0


______________________________________________________________________________________________________________________
README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Installation and Removal Notes
4. Features
5. Change Log


_____________________________________________________________________________________________________________________
1.  ABOUT AUTHOR
	-My name is AuroraGiggleFairy (AGF), previously known as RilesPlus
	-Started playing 7d2d during Alpha 12
	-Started attempting to mod in Alpha 17
	-First published a mod during Alpha 18
	-Where to find:
		https://discord.gg/Vm5eyW6N4r
		https://auroragigglefairy.github.io/
		https://www.twitch.tv/AuroraGiggleFairy
		https://7daystodiemods.com/
		https://www.nexusmods.com/7daystodie

		
______________________________________________________________________________________________________________________
2.  MOD PHILOSOPHY
	-Preferably easy installation and use!
	-Goal: Enhance Vanilla Gameplay!
	-Feedback and Testing is Beneficial!
	-Detailed Notes for Individual Preference and Mod Learning!
	-Full Language Support (best I can.)
		
	"The best mods rely on community involvement."


______________________________________________________________________________________________________________________
3.  INSTALLATION and REMOVAL NOTES
	*First, if you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
		-All questions welcome from newcombers to seasoned 7d2d people.

	-This is a server-side mod, meaning this mod can be installed on JUST the server and will work automatically for joining players.
	-Works with EAC on or off.
	-All 13 languages supported
	-FarmingPlus is SAFE to install on new or existing games.
	-FarmingPlus is DANGEROUS to remove from an existing game.


______________________________________________________________________________________________________________________
4.  FEATURES

	-Seed drop chance from player's plants system:
		-Level 0 in LivingOffTheLand, seed drop chance 25%
		-Level 1 in LivingOffTheLand, seed drop chance 50%
		-Level 2 in LivingOffTheLand, seed drop chance 75%
		-Level 3 in LivingOffTheLand, seed drop chance 100% (ALWAYS get a seed back)
	-World Crops have a 10% of dropping a seed.
	-Birdnest and Beehives now plantable for eggs, feathers, and honey.
		-Naturally discovered through traders and loot.
		-Unlocks at seed crafting level 20.
	-x5 seeds
		-Take 5 seeds, click recipe, and craft them into a single x5 seed.
		-Essentially 1 seed acts like 5 in one space.
		-Except for mushrooms and birdnests, requires x5 farm plots as well.


______________________________________________________________________________________________________________________
5.  CHANGELOG
v3.0.0
-Updated to V1

v2.0.0
-Updated the Bee Flower progression blocks to use a better model since A20! came out.
-REVAMPED the seed drop chance on player planted crops.
-Removed the recipe of 3 seeds per flower at max Living Off the Land.
-Returned the x5 versions of crops and farmplots from my A19 mods.

v1.2.0
-World crops 10% seed drop.
-Increased seed drop chance.

v1.1.0
-Tier 3 of living off the land actually reduces seed requirements for planting.
-Updated ReadMe to new format.

	
