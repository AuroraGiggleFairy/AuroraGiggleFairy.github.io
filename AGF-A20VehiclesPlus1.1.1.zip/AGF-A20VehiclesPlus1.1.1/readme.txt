VehiclesPlus
A20 - Version 1.1.1
AuroraGiggleFairy (AGF)
https://discord.gg/Vm5eyW6N4r


INSTALATION NOTES
1. SAFE for NEW and EXISTING games
2. Other mods may cause conflict, contact AGF on Discord

UN-INSTALATION NOTES
NOTE: This mod only makes adjustments and IS safe to remove on existing games
1. Delete this mod's folder



FEATURES
-Works Server Side and is EAC Friendly
-Full Language Support
-1 Extra Row of Storage in each vehicle
-Vehicle Speeds increased slightly and accordingly
-Safe to jump out of aircrafts, accidently or intentionally
-Expanded Seat Mod now does nothing
-Every vehicle can seat more than one person
	-Bicycle, MiniBike, Motorcycle has 2 seats
	-Truck has 5 seats
	-Gyrocopter has 4 seats (this one is funny)


_____________________________________________________________________________________________________________________
ABOUT AUTHOR
-Name changed from RilesPlus to AuroraGiggleFairy (AGF)
-Started playing 7d2d during Alpha 12
-Started attempting to mod in Alpha 17
-First published a mod during Alpha 18

WHERE TO FIND
https://discord.gg/Vm5eyW6N4r
https://7daystodiemods.com/
https://www.nexusmods.com/7daystodie
https://www.twitch.tv/AuroraGiggleFairy
		
MOD PHILOSOPHY
-Singeplayer AND/OR Server-Side!
-Goal: Enhance Vanilla Gameplay!
-Feedback and Testing is Beneficial!
		
"The best mods rely on community involvement."
	

