VanillaPlus
A20 - Version 3.1.1
Description and Updates


______________________________________________________________________________________________________________________
README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Warning about INSTALLING
4. Table of Contents for FEATURES
5. Detailed Feature Descriptions


_____________________________________________________________________________________________________________________
1.  ABOUT AUTHOR
	-Name changed from RilesPlus to AuroraGiggleFairy (AGF)
	-Started playing 7d2d during Alpha 12
	-Started attempting to mod in Alpha 17
	-First published a mod during Alpha 18
	-Where to find:
		https://discord.gg/Vm5eyW6N4r
		https://7daystodiemods.com/
		https://www.nexusmods.com/7daystodie
		https://www.twitch.tv/AuroraGiggleFairy
		
		
______________________________________________________________________________________________________________________
2.  MOD PHILOSOPHY
	-Singeplayer AND/OR Server-Side!
	-Goal: Enhance Vanilla Gameplay!
	-Feedback and Testing is Beneficial!
		
	"The best mods rely on community involvement."
	
	
______________________________________________________________________________________________________________________
3.  WARNINGS about INSTALLING
	*First, if you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r

	1. When Starting a New Game, it is safe to apply this mod.
	2. With additional mods, there may be errors. Feel free to ask for help, as I may be able to make a compatibility patch.
	

	

CHANGES since last version
	-NEW: Crafting List 
		
	
FULL FEATURE DESCRIPTIONS: 

Modifications of Existing Vanilla Game Functions
	-Stack Sizes carefully and intricately looked at to simplify and add convenience without adding too much pressure to the economy
	-Lanterns, Fashlights, and Burning Barrels can be picked up.
	-Car Salvaging Fix (turned off pass through damage)
	-Harvest a slight increase of sand from gravel and stone
	-Drawbridge has full rotation options
	-Animal Corpses stick around for 10 minutes instead of 5
	-Zombie Loot Drops stick around for 1 hour instead of 20 minutes
	-Zombie Corpses stick around for 10 seconds instead of 30 for performance support
	-Player Dropped Backpacks last 5 hours instead of 1
	-Batteries scrap into Acid
	-Mining Pallet Perk (bundling ores) now include Clay, Crushed Sand and scrap Brass
	-Bundling Ores now take 5 seconds each, instead of 10
	-Salvaging Tools improvements (wrench is slowest and takes most stamina, impact drive is fastest and takes least stamina)
	-Repair/Upgrade Tools improvements (stone axe is slowest and takes most stamina, nailgun is fastest and takes least stamina)
	-1 Mod slot per item tier level
	-All archery ammo requires feathers, and can craft feathers from plastics
	-5 Crafting Slots
	-Forges have 3 smelting slots
	-Some increase in player chest/storage sizes
	-Repair what was once unrepairable, the list is slowly growing (gravel, jail doors/bars)
	-(English Only)Renaming of schematics and mods for better sorting 
	-Chance for eggs in birdnest up from 35% to 63%
	
	
Additions
	-Farming of birdnest for eggs/feathers and beehive for honey (tier 3 living off the land perk)
	-Electriciy has LARGE banks (intention is to reduce number of wires used on a server. It is cheaty.)
	-Rebundle Ammo recipes
	-Wood Burning Stacks, 10 minutes and 1 hour options
	-Battle Axe Mod, like fireman's axe but for dealing more damage
	-DOOR VARIANT BLOCKS, find all your door types under Wood Door, Iron Door, and Vault Door
	-Can bundle all 7 volumes of a book to sell for more
	-Can bundle ALL books to sell for EVER more
	-Bundle Engines (better than increasing stack sizes)
	-Ammo Scrapping gives you each item used to construct, can also bundle larger amounts into easier to open bundles
	
	


