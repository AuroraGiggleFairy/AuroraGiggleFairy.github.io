DecoBlock
A20 - Version 1.1.3
Description and Updates


______________________________________________________________________________________________________________________
README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Features


_____________________________________________________________________________________________________________________
1.  ABOUT AUTHOR
	-Name changed from RilesPlus to AuroraGiggleFairy (AGF)
	-Started playing 7d2d during Alpha 12
	-Started attempting to mod in Alpha 17
	-First published a mod during Alpha 18
	-Where to find:
		https://discord.gg/Vm5eyW6N4r
		https://auroragigglefairy.github.io/
		https://www.twitch.tv/AuroraGiggleFairy
		https://7daystodiemods.com/
		https://www.nexusmods.com/7daystodie
		
		
______________________________________________________________________________________________________________________
2.  MOD PHILOSOPHY
	-Singeplayer AND/OR Server-Side!
	-Goal: Enhance Vanilla Gameplay!
	-Feedback and Testing is Beneficial!
	-Detailed Notes for Individual Preference and Mod Learning!
	-Full Language Support (best I can.)
		
	"The best mods rely on community involvement."
	
	
______________________________________________________________________________________________________________________
3.  Features
	*First, if you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
	

A single block variant that contains majority of in-game block models.
Craft at a workbench.
Levels in perkAdvancedEngineering slightly reduces ingredient costs.
Many are containers (10 x 8), both open and closed versions of container blocks.
Weaker than Wood Blocks (300hp), but high explosive resistance.
When a player breaks one, it returns to their inventory.
When blocks break to falls, zombies, or explosions, high chance of picking it up shortly after.
HIGH COMPATIBILITY as it only adds its own code and NOT dependent on existing ones.


POSSIBLE FUTURE UPDATE if requested enough:
-Making a secure (lockable) version of the decoration containers.