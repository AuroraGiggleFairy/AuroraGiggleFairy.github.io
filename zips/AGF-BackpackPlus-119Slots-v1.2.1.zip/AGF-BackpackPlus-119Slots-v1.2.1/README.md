# AGF 120-1 (119) Slot Backpack
7d2d Version 2  
**Version:** 1.2.1

---

## README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Need Help?
4. Compatibility
5. Installation
6. Removal
7. Features
8. Changelog

---

## 1. About Author
- My name is AuroraGiggleFairy (AGF), previously known as RilesPlus
- Started playing 7d2d during Alpha 8
- Started attempting to mod in Alpha 17
- First published a mod during Alpha 18
- Where to find:
  - https://discord.gg/Vm5eyW6N4r
  - https://auroragigglefairy.github.io/
  - https://www.twitch.tv/AuroraGiggleFairy
  - https://7daystodiemods.com/
  - https://www.nexusmods.com/7daystodie

---

## 2. Mod Philosophy
- Preferably easy installation and use!
- Goal: Enhance Vanilla Gameplay!
- Feedback and Testing is Beneficial!
- Detailed Notes for Individual Preference and Mod Learning!
- Accessibility is Required
- All 13 Languages Supported (best I can.)

> "The best mods rely on community involvement."

---

## 3. Need Help?
- AuroraGiggleFairy is available via Discord: https://discord.gg/Vm5eyW6N4r
- All questions welcome from newcomers and seasoned players alike.

---

## 4. Compatibility
- EAC Friendly: 
- Server Side: 
- Client Required for Multiplayer: 

---

## 5. Installation

### Safe to install on existing games: 

### Client
- Open "Run" (press Windows key + R)
- Type %appdata% and click OK
- Open the "Roaming" folder
- Open "7DaysToDie"
- Open or create the "Mods" folder
- Extract the mod here
- Make sure the mod folder is not inside another folder with the same name (move it up if needed)

### Server
- Use your server host’s file manager or a program like FileZilla
- Find the main server folder and open the "Mods" folder
- Extract the mod here
- Make sure the mod folder is not inside another folder with the same name (move it up if needed)

---

## 6. Removal

### Safe to remove from an existing game: 
- Simply locate the mod folder and delete it.

---

## 7. Features
<!-- FEATURES START -->
- 119 Slot Backpack, with 3 rows of encumbrance  slots (68 slots)
  - Updated encumbrance slots, buffs, twith interaction and perks. 
  - PackMule does free up all 68 slots.
  - Mobility is in sync with vanilla.
  - Lockable slots that is EASY to tell what is locked and what isn't.
  - Adds a craftable larger storage of wood/iron/steel, slots of 120/144/168.
  - Large storages are variant blocks with multiple shapes to choose from.
  - Breaking a larger storage returns it to your inventory.

*Some overlap of UI may occur as this is a LARGE backpack. You can modify UI zoom in game menu if you wish.*
<!-- FEATURES END -->

---

## 8. Changelog
<!-- CHANGELOG START -->
v1.2.1
- Fixed a controls missing conditional that made the vehicle storage not show.

v1.2.0
- Updated to work with version 2.5.

v1.1.0
- When you break an insecure large storage, the block itself (not items inside) return to your inventory.
- Added several more block shape options.
- Updated Localization

v1.0.0
- Made the mod
<!-- CHANGELOG END -->