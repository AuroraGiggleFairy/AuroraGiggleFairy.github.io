# AGF Smelting Plus
7d2d Version 2  
**Version:** 2.4.0  
[Download](https://github.com/AuroraGiggleFairy/AuroraGiggleFairy.github.io/raw/main/_zip/AGF-VP-SmeltingPlus.zip)

> 
---

## README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Need Help?
4. Compatibility
5. Installation
6. Removal
7. Features
8. Changelog

---

## 1. About Author
- My name is AuroraGiggleFairy (AGF), previously known as RilesPlus
- Started playing 7d2d during Alpha 8
- Started attempting to mod in Alpha 17
- First published a mod during Alpha 18
- Where to find:
  - https://discord.gg/Vm5eyW6N4r
  - https://auroragigglefairy.github.io/
  - https://www.twitch.tv/AuroraGiggleFairy
  - https://7daystodiemods.com/
  - https://www.nexusmods.com/7daystodie

---

## 2. Mod Philosophy
- Preferably easy installation and use!
- Goal: Enhance Vanilla Gameplay!
- Feedback and Testing is Beneficial!
- Detailed Notes for Individual Preference and Mod Learning!
- Accessibility is Required
- All 13 Languages Supported (best I can.)

> "The best mods rely on community involvement."

### **Language Support**

#### What languages do AGF mods support?
> - 7 Days to Die currently supports 13 languages: English, German, Spanish, French, Italian, Japanese, Koreana, Polish, Portuguese, Russian, Turkish, Simplified Chinese, and Traditional Chinese.  
> - *AGF mods add support for all 13 languages.*
> - *If you find a translation error, please let AGF know on [DISCORD](https://discord.gg/Vm5eyW6N4r).*

---

## 3. Need Help?
- AuroraGiggleFairy is available via Discord: https://discord.gg/Vm5eyW6N4r
- All questions welcome from newcomers and seasoned players alike.

---

## 4. Compatibility
- EAC Friendly: Yes
- Server Side: Yes
- Client Required for Multiplayer: No
- "AGF Smelting Plus" is SAFE to install on an existing game.
- "AGF Smelting Plus" is DANGEROUS to remove from an existing game.
- Unique Details: None

---

### What are 🖧 Server-Side 🖧 Mods? 
> - *Mods that can be installed on **JUST** the server and will automatically work for joining players.*
> - *Don’t let the word “server” confuse you—these mods also work in singleplayer if you install them on your own device.*

---

### What are 🖥️ Client-Side 🖥️ Mods? 
> - *For multiplayer, both the **HOST** and **PLAYER** must have these mods installed.*
> - *For singleplayer, just install them on your own device.*

---

### What are 🛡️ EAC-Friendly 🛡️ Mods? 
> - *EAC stands for Easy-Anti-Cheat.*
> - *EAC-Friendly means the mod will work with it enabled or disabled.* 
> - *If a mod is not EAC-Friendly, EAC must be turned off for it to work.*
>    - *Non-EAC-Friendly mods often have custom code.*

#### What are the risks of disabling EAC?
> - *Players may use hacks or cheats to gain unfair advantages.*
> - *Servers may be at higher risk for exploits, griefing, or disruptive behavior.*

#### Why disable EAC?
> - *Non-EAC-Friendly mods add amazing features and enhancements to the game.*

#### What are the best practices when running multiplayer without EAC on?
> - *Require a password and be conservative in distributing it.*
> - *There are tools available such as ALOC and Server Tools to add extra protections.*
> - *Optionally, require the whitelist system for the strictest limitation on who can join.*
> - *Seek out other server hosts and discuss what they do.*
>    - *You can do this on AGF's Discord as well: [DISCORD](https://discord.gg/Vm5eyW6N4r)*

---

## 5. Installation

> **All AGF mods are safe to install on existing games.**

### Singleplayer, Player-to-Player Multiplayer, or Client-Side Requirement
> - Open "Run" (press Windows key + R)
> - Type %appdata% and click OK
> - Open the "Roaming" folder
> - Open "7DaysToDie"
> - Open or create the "Mods" folder
> - Extract the mod here
> - Make sure the mod folder is not inside another folder with the same name (move it up if needed)

### Multiplayer Dedicated Server *(hosted sites or player-run)*
> - Find the main server folder and open the "Mods" folder
>    - *If using a hosted site, use their file manager or a program like FileZilla*
> - Extract the mod here
> - Make sure the mod folder is not inside another folder with the same name (move it up if needed)

### Special Note
> - The mod named **"0_TFP_Harmony"** is ***REQUIRED*** and should never be removed.
> - If it is missing, you can restore it by verifying your installation:
>    - In Steam, right click on 7 Days to Die
>    - Select "Properties"
>    - Select "Installed Files"
>    - Click on "Verify integrity of game files" and wait for completion.

---

### 6. Removal
> - The safest approach is to only remove mods when starting a new game.
>     - If you remove a mod that added new items or features, characters and/or the map may reset, or become permanently unplayable.
>     - If you are unsure, check the mod's readme for specific removal notes or ask in AGF's [DISCORD](https://discord.gg/Vm5eyW6N4r).
> - To remove, simply locate the mod folder and delete it. All done!

---

---

## 7. Features
<!-- FEATURES START -->
- Forges have 3 slots with text nicely centered.
    - Sand smelts at same ratio as rocks and clay, 1 to 5 (default was 1 to 4).
    - Manage your sand, rock, and clay by crafting/smelting a single nugget (for us OCD folk, lol!)
    - Workstation level 75 unlocks recipe to craft advanced smelting metals at a workbench.
    - 6,000 stack of advance smelting Iron, Brass, and Lead smelts at 1:5 ratio, like stones.
<!-- FEATURES END -->

---

## 8. Changelog
<!-- CHANGELOG START -->
v2.4.0
- Removed as the purple book conditional within windows.xml as it is now within the purple book mod.

v2.3.0
- Now works appropriately with version 2.5 (and previous game versions).
- Updated progression.xml and windows.xml.

v2.2.2
- Added hopefully a clearer description of what the 1:5 metals are.

v2.2.1
- Added conditional for if someone has Mining Plus installed or not.

v2.2.0
- Will now only apply purple book edits if you have my purple book installed.

v2.1.2
- expanded possible ways of crafting the adv smelt stacks, like from radiators and bundled stacks.

v2.1.1
- Had the ratio numbers written in reverse.... *facepalm*

v2.1.0
- added advanced smelting metals

v2.0.1
- Removed the tint color on the "units"

v2.0.0
- Updated to V1.0
<!-- CHANGELOG END -->