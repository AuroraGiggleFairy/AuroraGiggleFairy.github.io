# AGF BackpackPlus 60 Slots
7d2d Version 2  
**Version:** 3.2.1  
[Download](https://github.com/AuroraGiggleFairy/AuroraGiggleFairy.github.io/raw/main/_zip/AGF-BackpackPlus-60Slots.zip)

> 
---

## README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Need Help?
4. Compatibility
5. Installation
6. Removal
7. Features
8. Changelog

---

## 1. About Author
- My name is AuroraGiggleFairy (AGF), previously known as RilesPlus
- Started playing 7d2d during Alpha 8
- Started attempting to mod in Alpha 17
- First published a mod during Alpha 18
- Where to find:
  - https://discord.gg/Vm5eyW6N4r
  - https://auroragigglefairy.github.io/
  - https://www.twitch.tv/AuroraGiggleFairy
  - https://7daystodiemods.com/
  - https://www.nexusmods.com/7daystodie

---

## 2. Mod Philosophy
- Preferably easy installation and use!
- Goal: Enhance Vanilla Gameplay!
- Feedback and Testing is Beneficial!
- Detailed Notes for Individual Preference and Mod Learning!
- Accessibility is Required
- All 13 Languages Supported (best I can.)

> "The best mods rely on community involvement."

---

## 3. Need Help?
- AuroraGiggleFairy is available via Discord: https://discord.gg/Vm5eyW6N4r
- All questions welcome from newcomers and seasoned players alike.

---

## 4. Compatibility
- EAC Friendly: 
- Server Side: 
- Client Required for Multiplayer: 

---

## 5. Installation

### Safe to install on existing games: 

### Client
- Open "Run" (press Windows key + R)
- Type %appdata% and click OK
- Open the "Roaming" folder
- Open "7DaysToDie"
- Open or create the "Mods" folder
- Extract the mod here
- Make sure the mod folder is not inside another folder with the same name (move it up if needed)

### Server
- Use your server host’s file manager or a program like FileZilla
- Find the main server folder and open the "Mods" folder
- Extract the mod here
- Make sure the mod folder is not inside another folder with the same name (move it up if needed)

---

## 6. Removal

### Safe to remove from an existing game: 
- Simply locate the mod folder and delete it.

---

## 7. Features
<!-- FEATURES START -->
- Inventory size matches vanilla (no shrinking).
- 60-slot backpack with 3 rows (30 encumbrance slots).
- PackMule skill unlocks all encumbrance slots.
- Compatible with PackMule, buffs, Twitch integration, and mobility perks.
- Craftable large storage (wood, iron, steel) with 60/80/100 slots:
    - Easy-to-see lockable slots
    - Multiple storage block shapes
    - Breaking storage returns it to your inventory
<!-- FEATURES END -->

---

## 8. Changelog
<!-- CHANGELOG START -->
v3.2.1
- Updated for consistency and automation.

v3.2.0
- Updated to work with version 2.5.

v3.1.0
- When you break an insecure large storage, the block itself (not items inside) return to your inventory.
- Added several more block shape options.
- Updated Localization

v3.0.0
- Now utilizing conditionals in coding for this mod to work with both versions 2.1 and 2.2+.
- DO NOT ROLLBACK VERSIONS though, that will cause errors.

v2.4.0
- Updated for 7d2d version 2.2
- Lockable slots share same style across backpack, storages, and vehicles.

v2.3.2
- updated packmule localization again for value changes.

v2.3.1
- Updated PackMule Localization

v2.3.0
- Updated to V2.
- Updated the path to access block shapes with V2 version.
- Skipped all the other versions to match current.

v1.0.1
- Fixed inventory border height.

v1.0.0
- created the mod based on my v1 mods for backpack84 slots.
<!-- CHANGELOG END -->