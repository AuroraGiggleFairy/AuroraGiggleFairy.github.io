Backpack84
A20 - v1.2.1

______________________________________________________________________________________________________________________
README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Installation Notes
4. Features

_____________________________________________________________________________________________________________________
1.  ABOUT AUTHOR
	-My name is AuroraGiggleFairy (AGF), previously known as RilesPlus
	-Started playing 7d2d during Alpha 12
	-Started attempting to mod in Alpha 17
	-First published a mod during Alpha 18
	-Where to find:
		https://discord.gg/Vm5eyW6N4r
		https://auroragigglefairy.github.io/
		https://www.twitch.tv/AuroraGiggleFairy
		https://7daystodiemods.com/
		https://www.nexusmods.com/7daystodie
		
______________________________________________________________________________________________________________________
2.  MOD PHILOSOPHY
	-Preferably easy installation and use!
	-Goal: Enhance Vanilla Gameplay!
	-Feedback and Testing is Beneficial!
	-Detailed Notes for Individual Preference and Mod Learning!
	-Full Language Support (best I can.)
		
	"The best mods rely on community involvement."
	
______________________________________________________________________________________________________________________
3.  INSTALLATION NOTES
	*First, if you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r

	-This is a server-side mod, meaning this mod can be installed on JUST the server and will work automatically for joining players.
	-Works with EAC on or off.
	-All 14 languages supported
	-Backpack84 is SAFE to install on new or existing games.
	-Backpack84 if you remove this mod from an existing game, your game will very likely crash.

______________________________________________________________________________________________________________________
4.  FEATURES

84 Slot Backpack, with 3 rows of encumbrance  slots (36 slots)
Updated encumbrance slots, buffs, and perks. PackMule does free up all 36 slots.
Reduced encumbrance effect on mobility (move speed) to prevent immobility when fully encumbered and with heavy armor.
Lockable slots included.