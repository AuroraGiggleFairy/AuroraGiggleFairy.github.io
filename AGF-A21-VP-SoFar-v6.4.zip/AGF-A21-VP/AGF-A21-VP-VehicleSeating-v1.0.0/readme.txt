VanillaPlus - VehicleSeating
A21 - Version 1.0.0


______________________________________________________________________________________________________________
***Requires VP-1Core, otherwise known as Vanilla Plus Core***


______________________________________________________________________________________________________________
MAIN Features:
-Additional vehicle seats are now default, as in you don't have to use the expanded seat mod.
-5 seats in the truck. (I'm personally annoyed with how they did the 4 seats since it looks crap and I had 5 since A18.)
-Gyrocopter seats 4.... pretty funny how.
-Like the minibike and motorcycle, bicycles now seat 2.


______________________________________________________________________________________________________________
If you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
	-All questions welcome from newcombers to seasoned 7d2d people.
	
	
______________________________________________________________________________________________________________
More Details about the author and other sites described on the README in the CORE modlet.