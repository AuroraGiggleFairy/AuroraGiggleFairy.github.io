VanillaPlus - Smelting Plus
A21 - Version 1.0.0


______________________________________________________________________________________________________________
***This is a standalone mod, works well with vanilla plus.***


______________________________________________________________________________________________________________
MAIN Features:
-Forges have 3 slots with text nicely centered.
-Sand smelts at same ratio as rocks and clay, 1 to 5 (default was 1 to 4).
-Manage your sand, rock, and clay by crafting/smelting a single nugget (for us OCD folk, lol!)


______________________________________________________________________________________________________________
If you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r
	-All questions welcome from newcombrs to seasoned 7d2d people.
	
	
______________________________________________________________________________________________________________
More Details about the author and other sites described on the README in the CORE modlet.